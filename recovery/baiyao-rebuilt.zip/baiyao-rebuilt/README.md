# 百妖夜契 · 寒渊七境

2026-10-24 事件白话改造：批次1—3已落地；批次4自动验证完成，真人理解度验收仍待实际玩家参与。158项事件含新旧对照，来源／洞府／Boss回应、调查议价、军营连续交锋及援助报告已接入。见[逐项执行状态](docs/EVENT_REWORK_STATUS.md)、[本轮验证](docs/P2_VERIFICATION.md)及[事件审阅包](https://raw.githubusercontent.com/YONGLINGZ/CC/main/recovery/events-md-export.zip)。

本轮更新 **众生来意**：完成计划中全部37种关联敌人与十四组阵营遭遇，九位镇境者和五个特殊遭遇均已接入。P2、P3、P4本轮共新增91张独立选用画作，连同P1共111张；来源、凭证敌意、交涉／战斗互斥、一次援助和真实后续回应均有规则。详见[全量手册](docs/FACTIONS_COMPLETE.md)、[后四境画集](docs/previews/factions-p3.webp)、[特殊路线画集](docs/previews/factions-p4.webp)。

P5的规则、构建和浏览器验证以[实际检查记录](TESTING.md)为准；真实手机和真人试玩尚未完成。单局仍不保存，角色解锁保留，不恢复下一招预告，也不增加多敌人战斗。

此前更新 **灯渡与旧誓 · P2**：补齐四个前期Boss关联组，新增M04—M15十二种敌人、四处可交涉洞府、八件立场凭证和四件一次援助。前期五组现有15种关联敌人；加上已完成的焚愿组，共18种。新增32张独立画作：十二立绘、四交涉精英战斗姿态、十二物品及四背景。详见[本批规则与故事](docs/FRONTIER_P2.md)和[画集](docs/previews/frontier-p2.webp)；[P2 PNG母图包](https://raw.githubusercontent.com/YONGLINGZ/CC/main/recovery/frontier-art-originals.zip)。

此前更新 **器物与来意 · P1**：落实用户方案的首批六种关联小怪、两处可交涉洞府、四件立场凭证与两件专属援助。持有效支持凭证会被相应NPC识别并进入正常精英战；反对凭证可交谈，调查证物只开启问询。和平、救助、主动进攻和离去分别结算，一次机会不能双领。新绘20张运行画作（六待机＋六战斗＋六物品＋两背景），PNG母图单独保留。

[首批玩法与验收](docs/FACTIONS_P1.md) · [首批画集](docs/previews/factions-p1.webp) · [完整候选规划](docs/ENEMY_FACTIONS_PLAN.md) · [PNG母图包](https://raw.githubusercontent.com/YONGLINGZ/CC/main/recovery/factions-art-originals.zip)

P1与P2的阶段记录保留在各自手册；当前完整范围见本页开头的全量手册。

此前更新 **衣影与血誓**（2026-10-24，北京时间）：补齐九位镇境者与五个特殊遭遇的背景和连续旧事，共十四套三段任务链、42个四选项阶段；保留机仆两件信物齐全时自动唤醒、避战进境的结果。新增五套真实衣装、六张换血／夺生禁术及三个连续获取事件。战斗与人物志均已移除下一招的预测和招式序列，动作发生后仍显示实际伤害与日志。

夜铃与沈霜白各有五张换装图，沈霜白异变后另有五张对应图；五件衣装也各有物品原画。连同六张技能图、三个事件场景和四位剧情 Boss 重绘，该次新增33张独立生成画作。见[换装与禁术规则](docs/OUTFITS_AND_BLOOD.md)、[十四套 Boss 旧事](docs/BOSS_QUESTS.md)。

玄烬教的引灵实验反噬，寒渊被黑雾封闭。选择影契刺客夜铃、霜华剑修沈霜白，或在旅途中解锁第三位角色，沿七境深入。事件只交代当场见闻与对话，人物的打算留待途中判断。此前十套三阶段人间故事、洞府探索、人物支线与途中变故继续保留，每局只读取真正经历过的选择。

每境十段，从地图底部向上抵达顶部 Boss；全程七十段。每境独立从20套线路模板抽取布局，包含42—46处互斥分支地标。小型五边形图标与连线表示真实通路，每段只能走一个相连节点，下一境抵达后开放。

镇境阵容共有九位：前期五位依境按不同权重抽取三位且不重复，第四至第六境分别面对三位中期镇守，第七境迎战归墟司命。绛鳞是前期守关者。人物志可以查看画卷与背景，镜中人、卫烬、心影、逆仪绛鳞本轮已换为完整高分辨率原画。

当前共有76张技能、158种剧情事件、150段事件音效和432张运行 WebP。核心剑意、魂息常驻名称、数字和刻度；敌方状态只在实际施加后显示符纹与右下角层数。卡牌目标选择仍有规则层预览，不公开敌方下一招。

## 下载与启动

原始PNG母图另包保存：[P3后四境24张](https://raw.githubusercontent.com/YONGLINGZ/CC/main/recovery/later-p3-art-originals.zip) · [P4特殊路线35张](https://raw.githubusercontent.com/YONGLINGZ/CC/main/recovery/special-p4-art-originals.zip)。试玩只需下面的游戏包或单文件。

- [完整游戏 ZIP](https://raw.githubusercontent.com/YONGLINGZ/CC/main/recovery/baiyao-rebuilt.zip)：全部解压，打开 `index.html`，保留 `assets/`。
- [完整单文件 HTML](https://raw.githubusercontent.com/YONGLINGZ/CC/main/baiyao-standalone.html)：保存为 `.html`，用桌面浏览器打开。

完全离线，无需安装、账号或大模型 API。攻击牌先点牌再点敌人，同牌再点一次或按 Esc 取消；无目标牌直接使用。顶部可查看牌组、包裹、手记、随身装备和人物志。开局带两份回春草，战斗中每个玩家回合可用一件药物。

夜铃和沈霜白开局衣囊持有墨羽行衣，默认仍穿原装；在「随身装备」中选择穿上即可更改立绘和效果。其余四套可在千灯灵坊购买，购买不会自动装备。战斗、战利结算及未处理事件中不能换装，衣装效果不叠加，重新开始清空购买并恢复原装。

本局不存档，角色解锁单独保存在浏览器，也可复制凭证迁移。浏览器支持时会对正在进行的一局显示离页确认；移动端仍可能直接关闭或回收页面。

原装保留三档生命立绘。五套衣装本轮没有另外绘制50%／25%两档战损图，仍有伤势标签与二维表现，低血量不会换回原装。人物采用静态原画配 CSS 动作和技能特效，尚无正式 Live2D 模型。自动回归策略仍可读取规则层内部意图，其胜率不能替代隐藏预告后的人工难度评价。

玩法见 [GAME_README.md](GAME_README.md)，实际验证范围与未达数值目标见 [TESTING.md](TESTING.md)，文件恢复见 [PERSISTENCE.md](PERSISTENCE.md)。

画集：[主角换装](docs/previews/wardrobe.webp) · [异变换装](docs/previews/wardrobe-fallen.webp) · [新技能与事件](docs/previews/blood-skills.webp) · [剧情 Boss](docs/previews/story-bosses.webp) · [九位镇境者](docs/previews/bosses-v11.webp) · [十段人间事](docs/previews/tales-v12.webp)。
