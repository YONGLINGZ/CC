# 潮尺停下的地方

- 事件 ID：`faction_marsh_boss_source`
- 导出来源：当前规则数据

## 背景与叙事

巡卒按潮尺把水停在村口。高地的人因此活着，低地的屋顶却还没露出来。抱瓮的老妇记得自己家门朝哪边，仍不肯松手。

舟匠要准备开堤，但图上有些屋舍还没撤空。加固封水与准备泄潮都有受益者，也都有不得不等的人。

## 选项

### 1. 加固封水板，接受定潮护持

主动接受且公开显露的约定；凿堤舟匠会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；凿堤舟匠会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：tide_pact
- **factionKey**：support

### 2. 协助整备凿堤舟，接下泄潮约定

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：breach_order
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_marsh_boss_source
- **name**：潮尺停下的地方
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：marsh_boss
  - **kind**：source
  - **nodeId**：export-faction_marsh_boss_source
