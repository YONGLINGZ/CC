# 无钟墓室

- 事件 ID：`faction_bell_boss_cave`
- 导出来源：当前规则数据

## 背景与叙事

墓室不挂钟。衣外的续钟铃结一响，掘名者会认为你来把姓名重新留在钟阵里。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_bell_boss_cave
- **name**：无钟墓室
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：bell_boss
  - **kind**：cave
  - **nodeId**：export-faction_bell_boss_cave
