# 尚未系上的名字

- 事件 ID：`faction_bell_boss_source`
- 导出来源：当前规则数据

## 背景与叙事

执幡役捧着一个还没系上的名字。家属盼再听一次声音，抬棺人却说自己已经在同一段路上走了十年。

补全墓名是纪念，系入钟阵才是留魂。两者不是一件事；选择前，你看见铃绳确实连着钟阵。

## 选项

### 1. 把新名系入钟阵，接过铃结

主动接受且公开显露的约定；断钟掘名人会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；断钟掘名人会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：bell_knot
- **factionKey**：support

### 2. 取下留魂绳，承诺停钟归骨

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：bell_wedge
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_bell_boss_source
- **name**：尚未系上的名字
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：bell_boss
  - **kind**：source
  - **nodeId**：export-faction_bell_boss_source
