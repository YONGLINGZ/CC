# 双信洞

- 事件 ID：`faction_feiye_echo_cave`
- 导出来源：当前规则数据

## 背景与叙事

两封回信放在不同灯下。代答承印会被求真人认作继续替人作答的许可。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_feiye_echo_cave
- **name**：双信洞
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：feiye_echo
  - **kind**：cave
  - **nodeId**：export-faction_feiye_echo_cave
