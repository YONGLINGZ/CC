# 两封同笔迹的信

- 事件 ID：`faction_feiye_echo_source`
- 导出来源：当前规则数据

## 背景与叙事

墨偶说，收信的人需要的也许只是有人回答。求真人拿着两封同样的信，却不肯让另一张脸替自己决定该相信谁。

继续代答，可以维持一项具体的等待；核验信件，则可能让等信的人失去支撑。两封信的折痕不能直接证明谁从未履行过承诺。

## 选项

### 1. 许可墨偶继续代答这位收信人

主动接受且公开显露的约定；拆函求真人会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；拆函求真人会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：reply_seal
- **factionKey**：support

### 2. 核对两封回函，承接送信约定

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：true_split
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_feiye_echo_source
- **name**：两封同笔迹的信
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：feiye_echo
  - **kind**：source
  - **nodeId**：export-faction_feiye_echo_source
