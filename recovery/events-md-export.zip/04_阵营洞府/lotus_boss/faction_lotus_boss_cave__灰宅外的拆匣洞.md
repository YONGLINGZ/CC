# 灰宅外的拆匣洞

- 事件 ID：`faction_lotus_boss_cave`
- 导出来源：当前规则数据

## 背景与叙事

洞内有人专拆护宅机关；家令的红光藏不过他们的眼。

这处洞府尚未探入。你可以看清携物的风险，再决定是否进去。

洞内有人专拆护宅机关；家令的红光藏不过他们的眼。

## 选项

### 1. 探入洞府

进入后按已持有效凭证与本次目击判断态度。

**结果：** 进入后按已持有效凭证与本次目击判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕过洞口

不进入洞府、不获奖励。

**结果：** 不进入洞府、不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_lotus_boss_cave
- **name**：灰宅外的拆匣洞
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：lotus_boss
  - **kind**：cave
  - **nodeId**：export-faction_lotus_boss_cave
