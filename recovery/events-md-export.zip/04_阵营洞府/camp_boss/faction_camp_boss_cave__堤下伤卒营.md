# 堤下伤卒营

- 事件 ID：`faction_camp_boss_cave`
- 导出来源：当前规则数据

## 背景与叙事

营门军徽都已剪去。公开佩着拘逃军令的人，会被守营者视作追捕者。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_camp_boss_cave
- **name**：堤下伤卒营
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：camp_boss
  - **kind**：cave
  - **nodeId**：export-faction_camp_boss_cave
