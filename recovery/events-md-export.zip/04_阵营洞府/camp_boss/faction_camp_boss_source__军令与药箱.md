# 军令与药箱

- 事件 ID：`faction_camp_boss_source`
- 导出来源：当前规则数据

## 背景与叙事

残卒要求你帮忙追回离营者：“他们带走药，留下的人就得死。”药役背着锁箱，却说自己送出的每一份药都记得人名。

堤下有人用空担架接应。离营并不意味着不再救人，追上逃卒也不能保证药会公平分给伤者。

## 选项

### 1. 接下军令，承诺追回药物

主动接受且公开显露的约定；断誓逃卒会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；断誓逃卒会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：pursuit_order
- **factionKey**：support

### 2. 打开侧栅，协助伤卒离营

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：pass_fold
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_camp_boss_source
- **name**：军令与药箱
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：camp_boss
  - **kind**：source
  - **nodeId**：export-faction_camp_boss_source
