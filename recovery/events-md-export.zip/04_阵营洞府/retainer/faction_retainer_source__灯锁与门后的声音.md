# 灯锁与门后的声音

- 事件 ID：`faction_retainer_source`
- 导出来源：当前规则数据

## 背景与叙事

门卒说，门外有黑雾，闭门才是护人。灯匠说自己做过这道锁，所以更知道里面的人不能从另一边打开。

有人想出去找家人，有人仍想留下避难。加固门与拆开出口都是具体选择，不能把所有人的意愿写成同一种。

## 选项

### 1. 接下守门约定，加固避难所

主动接受且公开显露的约定；退灯逃客会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；退灯逃客会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：lock_order
- **factionKey**：support

### 2. 帮助拆开一段门环，留下出口

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：exit_ring
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_retainer_source
- **name**：灯锁与门后的声音
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：retainer
  - **kind**：source
  - **nodeId**：export-faction_retainer_source
