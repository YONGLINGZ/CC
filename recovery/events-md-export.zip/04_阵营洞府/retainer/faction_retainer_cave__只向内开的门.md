# 只向内开的门

- 事件 ID：`faction_retainer_cave`
- 导出来源：当前规则数据

## 背景与叙事

门边铜环正被拆开。留灯锁令公开悬在身上，会被逃客看作继续封门的命令。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_retainer_cave
- **name**：只向内开的门
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：retainer
  - **kind**：cave
  - **nodeId**：export-faction_retainer_cave
