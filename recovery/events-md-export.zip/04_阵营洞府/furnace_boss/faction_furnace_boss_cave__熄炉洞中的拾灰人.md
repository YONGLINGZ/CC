# 熄炉洞中的拾灰人

- 事件 ID：`faction_furnace_boss_cave`
- 导出来源：当前规则数据

## 背景与叙事

炉门上划去了朱印：带着有效续炉寿契的人不受欢迎。

这处洞府尚未探入。你可以看清携物的风险，再决定是否进去。

炉门上划去了朱印：带着有效续炉寿契的人不受欢迎。

## 选项

### 1. 探入洞府

进入后按已持有效凭证与本次目击判断态度。

**结果：** 进入后按已持有效凭证与本次目击判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕过洞口

不进入洞府、不获奖励。

**结果：** 不进入洞府、不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_furnace_boss_cave
- **name**：熄炉洞中的拾灰人
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：furnace_boss
  - **kind**：cave
  - **nodeId**：export-faction_furnace_boss_cave
