# 愿帖上的空位

- 事件 ID：`faction_furnace_boss_source`
- 导出来源：当前规则数据

## 背景与叙事

炉役把愿帖夹进炉口：“停了火，等着药的人怎么办？”墙边一位老人却只想拿回自己的寿契。

原寿契是调查证物，只有你主动接受供养才会留下续炉炉纹。支持与反对都有人付代价。

## 选项

### 1. 接受护持与约定

自愿接受炉火护持，炉纹自动可辨；拾灰人会立即敌对。赤绫战首回合护盾+8一次。原寿契证物不等于此契。

**结果：** 自愿接受炉火护持，炉纹自动可辨；拾灰人会立即敌对。赤绫战首回合护盾+8一次。原寿契证物不等于此契。

**规则字段：**

- **questItem**：furnace_pact
- **factionKey**：support

### 2. 接受另一方的委托

与退契者共按的停炉凭证，可向拾灰人交涉；不能抵消续炉寿契引发的敌意。

**结果：** 与退契者共按的停炉凭证，可向拾灰人交涉；不能抵消续炉寿契引发的敌意。

**规则字段：**

- **questItem**：charcoal_seal
- **factionKey**：oppose

### 3. 只核实现场，不表立场

留下证词，不接受任何可被识别的立场凭证。

**结果：** 留下证词，不接受任何可被识别的立场凭证。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

不改变数值，不认作背弃。

**结果：** 不改变数值，不认作背弃。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_furnace_boss_source
- **name**：愿帖上的空位
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：furnace_boss
  - **kind**：source
  - **nodeId**：export-faction_furnace_boss_source
