# 黑潮边的一片白鳞

- 事件 ID：`faction_snake_ascended_source`
- 导出来源：当前规则数据

## 背景与叙事

黑鳞寄生在旧蜕里，仍借着封井者的形状行走。采鳞人把一片内鳞压在裂口上，说那是还没被井吞没的部分。

引潮可以换取本次交锋的护持，却会让封裂者认出你在借污染取力。封住一道裂隙，也不能宣称绛鳞已经恢复。

## 选项

### 1. 引导一缕黑潮，接受逆仪护持

主动接受且公开显露的约定；封井采鳞人会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；封井采鳞人会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：corrupt_scale
- **factionKey**：support

### 2. 协助以白鳞压裂，留下封潮约定

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：tide_wedge
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_snake_ascended_source
- **name**：黑潮边的一片白鳞
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：snake_ascended
  - **kind**：source
  - **nodeId**：export-faction_snake_ascended_source
