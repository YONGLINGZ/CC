# 井壁白鳞窟

- 事件 ID：`faction_snake_ascended_cave`
- 导出来源：当前规则数据

## 背景与叙事

井壁白鳞压着黑潮。逆仪引鳞的紫黑光会被采鳞人视作继续引潮取力的标志。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_snake_ascended_cave
- **name**：井壁白鳞窟
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：snake_ascended
  - **kind**：cave
  - **nodeId**：export-faction_snake_ascended_cave
