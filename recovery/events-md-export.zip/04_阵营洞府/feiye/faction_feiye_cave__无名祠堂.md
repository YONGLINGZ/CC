# 无名祠堂

- 事件 ID：`faction_feiye_cave`
- 导出来源：当前规则数据

## 背景与叙事

宫绳已被剪断。归宫名契挂在衣外，讨名者会把它认作来收人的凭证。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_feiye_cave
- **name**：无名祠堂
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：feiye
  - **kind**：cave
  - **nodeId**：export-faction_feiye_cave
