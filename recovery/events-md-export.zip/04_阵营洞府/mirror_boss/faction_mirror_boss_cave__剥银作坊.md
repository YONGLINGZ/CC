# 剥银作坊

- 事件 ID：`faction_mirror_boss_cave`
- 导出来源：当前规则数据

## 背景与叙事

作坊中的镜面都已露出木背。无瑕面契的白光，会被剥银匠视作继续代画的记号。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_mirror_boss_cave
- **name**：剥银作坊
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：mirror_boss
  - **kind**：cave
  - **nodeId**：export-faction_mirror_boss_cave
