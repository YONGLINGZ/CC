# 镜面上被擦掉的伤

- 事件 ID：`faction_mirror_boss_source`
- 导出来源：当前规则数据

## 背景与叙事

描相侍能替一面镜子遮去裂痕，裂面证人却说那道裂痕是自己最后记得的东西。两人都不愿对方替自己选择。

修镜护持收12灵石，遮住的是镜上痕迹，不会替失忆者找回过去。剥银会终止一面镜的复制，也会让依赖那副面貌的人再也看不到它。

## 选项

### 1. 付12灵石修镜，接受抹痕护持

主动接受且公开显露的约定；剥银匠会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；剥银匠会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：mask_contract
- **factionKey**：support
- **goldCost**：12

### 2. 协助剥去一面镜的银层

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：glass_scraper
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_mirror_boss_source
- **name**：镜面上被擦掉的伤
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：mirror_boss
  - **kind**：source
  - **nodeId**：export-faction_mirror_boss_source
