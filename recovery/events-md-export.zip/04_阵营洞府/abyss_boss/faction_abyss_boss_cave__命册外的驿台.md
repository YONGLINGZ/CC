# 命册外的驿台

- 事件 ID：`faction_abyss_boss_cave`
- 导出来源：当前规则数据

## 背景与叙事

驿台不收续命赤签。有效赤签的红线一露出来，无籍客就会将你视作命枢的追索者。

挂在衣外的信物藏不过这里的眼睛。你还可以绕行。

## 选项

### 1. 探入洞府

按现有有效凭证判断态度。

**结果：** 按现有有效凭证判断态度。

**规则字段：**

- **factionAction**：enter

### 2. 绕行

关闭本次机会，不获奖励。

**结果：** 关闭本次机会，不获奖励。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_abyss_boss_cave
- **name**：命册外的驿台
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：abyss_boss
  - **kind**：cave
  - **nodeId**：export-faction_abyss_boss_cave
