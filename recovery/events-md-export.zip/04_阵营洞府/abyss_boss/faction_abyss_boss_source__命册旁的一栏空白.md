# 命册旁的一栏空白

- 事件 ID：`faction_abyss_boss_source`
- 导出来源：当前规则数据

## 背景与叙事

录吏说命枢可以替人接住一次灾厄。缠身客问，那次灾厄最后落在谁身上；录吏只指向册背的一栏。

接受赤签，司命允你一度护身，也会留下公开红线。断签者要你先舍下属于自己的那次庇护，再谈不替别人代签的路。

## 选项

### 1. 接受续命赤签与一次护持

主动接受且公开显露的约定；断线无籍客会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**结果：** 主动接受且公开显露的约定；断线无籍客会认出并引战。对应Boss首回合护盾+8一次；护持用尽仍可识别。

**规则字段：**

- **questItem**：life_slip
- **factionKey**：support

### 2. 放弃赤签首回合8护盾，签下空符

主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**结果：** 主动实施另一方行动的凭证，可交涉；不能抵消有效支持凭证的敌意。

**规则字段：**

- **questItem**：blank_cut
- **factionKey**：oppose

### 3. 只记录眼前证词

记下现场说法与痕迹，暂不接任何约定。

**结果：** 记下现场说法与痕迹，暂不接任何约定。

**规则字段：**

- **factionKey**：investigate

### 4. 离去

收起行囊，继续赶路。

**结果：** 收起行囊，继续赶路。

**规则字段：**

- **factionKey**：leave

## 机器可读字段摘录

- **id**：faction_abyss_boss_source
- **name**：命册旁的一栏空白
- **type**：
- **glyph**：灯
- **kicker**：器物与来意
- **tale**：
- **bossQuest**：
- **factionEvent**：
  - **boss**：abyss_boss
  - **kind**：source
  - **nodeId**：export-faction_abyss_boss_source
