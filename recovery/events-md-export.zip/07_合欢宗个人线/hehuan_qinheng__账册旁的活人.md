# 账册旁的活人

- 事件 ID：`hehuan_qinheng`
- 规则来源：dev/hehuan.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

秦蘅手腕的线扣在案脚，动一下，案上的铃就响。宋箴说外堂还等着这笔药钱，秦蘅拿指甲掐住线头：“我的名字在上面，不等于我答应过。”

晏绮罗没有去碰那根线：“药钱我会要。人，我今天也要。”她将扇骨抵上案角，秦蘅看清她的手，才松开指甲。

宋箴看着晏绮罗空着的手，将账册翻到没有字的那一面。

## 选项

### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

**点击前已知代价：** 支付48灵石

**结果：** 宋箴数了两遍钱，才解开案脚的线。秦蘅抽走写有自己名字的纸，晏绮罗抓住册子另一端，两人一同退出白线。

**规则字段：**

- **goldCost**：48
- **questItem**：hehuan_ledger_original
- **hehuanFlags**：
  - **rescueReached**：true
  - **rescuedQinHeng**：true
  - **ledgerOriginal**：true
  - **boughtLedger**：true
  - **agentSpared**：true

### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

**点击前已知代价：** 进入宗门代理·宋箴战，落败结束本局

**结果：** 宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

**规则字段：**

- **battle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **hehuanBattle**：
    - **victoryFlags**：
      - **rescueReached**：true
      - **rescuedQinHeng**：true
      - **ledgerOriginal**：true
      - **killedAgent**：true
      - **agentDefeated**：true
    - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
    - **victoryItems**：
      - hehuan_ledger_original
- **hehuanBattle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **victoryFlags**：
    - **rescueReached**：true
    - **rescuedQinHeng**：true
    - **ledgerOriginal**：true
    - **killedAgent**：true
    - **agentDefeated**：true
  - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
  - **victoryItems**：
    - hehuan_ledger_original

### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

**点击前已知代价：** 进入宗门代理·宋箴战，落败结束本局

**结果：** 晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

**规则字段：**

- **battle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **hehuanBattle**：
    - **victoryFlags**：
      - **rescueReached**：true
      - **rescuedQinHeng**：true
      - **ledgerOriginal**：true
      - **killedAgent**：true
      - **agentDefeated**：true
    - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
    - **victoryItems**：
      - hehuan_ledger_original
- **hehuanBattle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **victoryFlags**：
    - **rescueReached**：true
    - **rescuedQinHeng**：true
    - **ledgerOriginal**：true
    - **killedAgent**：true
    - **agentDefeated**：true
  - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
  - **victoryItems**：
    - hehuan_ledger_original

### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

**结果：** 宋箴推来钱袋，重新压住账册。秦蘅喊了一次晏绮罗的全名。晏绮罗将袋口束紧，扇子一直没有打开。

**规则字段：**

- **goldGain**：55
- **hehuanFlags**：
  - **rescueReached**：true
  - **tookHushMoney**：true
  - **rescueAbandoned**：true
  - **agentSpared**：true

## 机器可读字段摘录

- **id**：hehuan_qinheng
- **name**：账册旁的活人
- **type**：
- **glyph**：纱
- **kicker**：合欢旧案
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：新增角色事件。晏绮罗个人剧情，按实际营救、证词与账册处置显示分支；不覆盖原地图节点。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### hehuan / default

秦蘅手腕的线扣在案脚，动一下，案上的铃就响。宋箴说外堂还等着这笔药钱，秦蘅拿指甲掐住线头：“我的名字在上面，不等于我答应过。”

晏绮罗没有去碰那根线：“药钱我会要。人，我今天也要。”她将扇骨抵上案角，秦蘅看清她的手，才松开指甲。

宋箴看着晏绮罗空着的手，将账册翻到没有字的那一面。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴数了两遍钱，才解开案脚的线。秦蘅抽走写有自己名字的纸，晏绮罗抓住册子另一端，两人一同退出白线。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴推来钱袋，重新压住账册。秦蘅喊了一次晏绮罗的全名。晏绮罗将袋口束紧，扇子一直没有打开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / evidence

秦蘅手腕的线扣在案脚，动一下，案上的铃就响。宋箴说外堂还等着这笔药钱，秦蘅拿指甲掐住线头：“我的名字在上面，不等于我答应过。”

晏绮罗没有去碰那根线：“药钱我会要。人，我今天也要。”她将扇骨抵上案角，秦蘅看清她的手，才松开指甲。

晏绮罗摊开抄件，指住宋箴的签押。他把账册挪远，印迹仍露在外面。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴数了两遍钱，才解开案脚的线。秦蘅抽走写有自己名字的纸，晏绮罗抓住册子另一端，两人一同退出白线。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 用已核证据逼宋箴放人

出示路引抄件或信使证词，核对签押；宋箴无法否认，交出原件并放人。本次不支付、不战斗。

结果：签押和日期对上。宋箴把笔扔到地上，剪开引灵线。秦蘅弯腰捡笔，划去自己的名字，把原册塞到晏绮罗怀里。

规则：{"key":"negotiate","questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"negotiatedRescue":true,"agentSpared":true}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴推来钱袋，重新压住账册。秦蘅喊了一次晏绮罗的全名。晏绮罗将袋口束紧，扇子一直没有打开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / rescued-original

秦蘅手腕的线扣在案脚，动一下，案上的铃就响。宋箴说外堂还等着这笔药钱，秦蘅拿指甲掐住线头：“我的名字在上面，不等于我答应过。”

晏绮罗没有去碰那根线：“药钱我会要。人，我今天也要。”她将扇骨抵上案角，秦蘅看清她的手，才松开指甲。

宋箴看着晏绮罗空着的手，将账册翻到没有字的那一面。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴数了两遍钱，才解开案脚的线。秦蘅抽走写有自己名字的纸，晏绮罗抓住册子另一端，两人一同退出白线。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴推来钱袋，重新压住账册。秦蘅喊了一次晏绮罗的全名。晏绮罗将袋口束紧，扇子一直没有打开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / hush

秦蘅手腕的线扣在案脚，动一下，案上的铃就响。宋箴说外堂还等着这笔药钱，秦蘅拿指甲掐住线头：“我的名字在上面，不等于我答应过。”

晏绮罗没有去碰那根线：“药钱我会要。人，我今天也要。”她将扇骨抵上案角，秦蘅看清她的手，才松开指甲。

宋箴看着晏绮罗空着的手，将账册翻到没有字的那一面。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴数了两遍钱，才解开案脚的线。秦蘅抽走写有自己名字的纸，晏绮罗抓住册子另一端，两人一同退出白线。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴推来钱袋，重新压住账册。秦蘅喊了一次晏绮罗的全名。晏绮罗将袋口束紧，扇子一直没有打开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / handed

秦蘅手腕的线扣在案脚，动一下，案上的铃就响。宋箴说外堂还等着这笔药钱，秦蘅拿指甲掐住线头：“我的名字在上面，不等于我答应过。”

晏绮罗没有去碰那根线：“药钱我会要。人，我今天也要。”她将扇骨抵上案角，秦蘅看清她的手，才松开指甲。

宋箴敲敲合上的册子：“季远呢？我还等他来对账。”



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴数了两遍钱，才解开案脚的线。秦蘅抽走写有自己名字的纸，晏绮罗抓住册子另一端，两人一同退出白线。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴推来钱袋，重新压住账册。秦蘅喊了一次晏绮罗的全名。晏绮罗将袋口束紧，扇子一直没有打开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}