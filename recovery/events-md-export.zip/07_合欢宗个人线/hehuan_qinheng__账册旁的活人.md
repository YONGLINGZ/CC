# 账册旁的活人

- 事件 ID：`hehuan_qinheng`
- 规则来源：dev/hehuan.js；呈现改写：dev/event-editorial.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

秦蘅还活着，手腕上的引灵线一端扣在案脚。宋箴把账册横在她面前：“长老付过价。她留下，外堂才有药领。”

“我的名字在册上，不等于我答应过。”秦蘅扯住线头。晏绮罗看着宋箴：“原件和人，你开价，还是让我查？”

你没有可靠口供，门牌只证明这里曾接收过宗门的人。

## 选项

### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

**点击前已知代价：** 支付48灵石

**结果：** 宋箴点清灵石，亲手撤去案脚引灵符。秦蘅拿走写着自己名字的账页，跟你走出白线。你买下了原件，也把收钱的人留在了世上。

**规则字段：**

- **goldCost**：48
- **questItem**：hehuan_ledger_original
- **hehuanFlags**：
  - **rescueReached**：true
  - **rescuedQinHeng**：true
  - **ledgerOriginal**：true
  - **boughtLedger**：true
  - **agentSpared**：true

### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

**点击前已知代价：** 进入宗门代理·宋箴战，落败结束本局

**结果：** 宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

**规则字段：**

- **battle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **hehuanBattle**：
    - **victoryFlags**：
      - **rescueReached**：true
      - **rescuedQinHeng**：true
      - **ledgerOriginal**：true
      - **killedAgent**：true
      - **agentDefeated**：true
    - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
    - **victoryItems**：
      - hehuan_ledger_original
- **hehuanBattle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **victoryFlags**：
    - **rescueReached**：true
    - **rescuedQinHeng**：true
    - **ledgerOriginal**：true
    - **killedAgent**：true
    - **agentDefeated**：true
  - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
  - **victoryItems**：
    - hehuan_ledger_original

### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

**点击前已知代价：** 进入宗门代理·宋箴战，落败结束本局

**结果：** 晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

**规则字段：**

- **battle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **hehuanBattle**：
    - **victoryFlags**：
      - **rescueReached**：true
      - **rescuedQinHeng**：true
      - **ledgerOriginal**：true
      - **killedAgent**：true
      - **agentDefeated**：true
    - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
    - **victoryItems**：
      - hehuan_ledger_original
- **hehuanBattle**：
  - **enemyId**：raider
  - **kind**：elite
  - **name**：宗门代理·宋箴
  - **victoryFlags**：
    - **rescueReached**：true
    - **rescuedQinHeng**：true
    - **ledgerOriginal**：true
    - **killedAgent**：true
    - **agentDefeated**：true
  - **victoryOutcome**：宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。
  - **victoryItems**：
    - hehuan_ledger_original

### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

**结果：** 宋箴把灵石推来，账册重新合拢。秦蘅没有喊她师姐，只把自己的名字念了一遍。你收了钱，从白线外离开。

**规则字段：**

- **goldGain**：55
- **hehuanFlags**：
  - **rescueReached**：true
  - **tookHushMoney**：true
  - **rescueAbandoned**：true
  - **agentSpared**：true

## 机器可读字段摘录

- **id**：hehuan_qinheng
- **name**：账册旁的活人
- **type**：
- **glyph**：纱
- **kicker**：合欢旧案
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：新增角色事件。晏绮罗个人剧情，按实际营救、证词与账册处置显示分支；不覆盖原地图节点。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### hehuan / default

秦蘅还活着，手腕上的引灵线一端扣在案脚。宋箴把账册横在她面前：“长老付过价。她留下，外堂才有药领。”

“我的名字在册上，不等于我答应过。”秦蘅扯住线头。晏绮罗看着宋箴：“原件和人，你开价，还是让我查？”

你没有可靠口供，门牌只证明这里曾接收过宗门的人。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴点清灵石，亲手撤去案脚引灵符。秦蘅拿走写着自己名字的账页，跟你走出白线。你买下了原件，也把收钱的人留在了世上。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴把灵石推来，账册重新合拢。秦蘅没有喊她师姐，只把自己的名字念了一遍。你收了钱，从白线外离开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / evidence

秦蘅还活着，手腕上的引灵线一端扣在案脚。宋箴把账册横在她面前：“长老付过价。她留下，外堂才有药领。”

“我的名字在册上，不等于我答应过。”秦蘅扯住线头。晏绮罗看着宋箴：“原件和人，你开价，还是让我查？”

你带来的路引抄件上，宋箴的签押与门内账册相同。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴点清灵石，亲手撤去案脚引灵符。秦蘅拿走写着自己名字的账页，跟你走出白线。你买下了原件，也把收钱的人留在了世上。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 用已核证据逼宋箴放人

出示路引抄件或信使证词，核对签押；宋箴无法否认，交出原件并放人。本次不支付、不战斗。

结果：宋箴的签押与接收时间一项项对上。秦蘅自己划去受领栏，拿走原件。宋箴放开引灵线，要求你别把账交回同一位长老。

规则：{"key":"negotiate","questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"negotiatedRescue":true,"agentSpared":true}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴把灵石推来，账册重新合拢。秦蘅没有喊她师姐，只把自己的名字念了一遍。你收了钱，从白线外离开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / rescued-original

秦蘅还活着，手腕上的引灵线一端扣在案脚。宋箴把账册横在她面前：“长老付过价。她留下，外堂才有药领。”

“我的名字在册上，不等于我答应过。”秦蘅扯住线头。晏绮罗看着宋箴：“原件和人，你开价，还是让我查？”

你没有可靠口供，门牌只证明这里曾接收过宗门的人。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴点清灵石，亲手撤去案脚引灵符。秦蘅拿走写着自己名字的账页，跟你走出白线。你买下了原件，也把收钱的人留在了世上。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴把灵石推来，账册重新合拢。秦蘅没有喊她师姐，只把自己的名字念了一遍。你收了钱，从白线外离开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / hush

秦蘅还活着，手腕上的引灵线一端扣在案脚。宋箴把账册横在她面前：“长老付过价。她留下，外堂才有药领。”

“我的名字在册上，不等于我答应过。”秦蘅扯住线头。晏绮罗看着宋箴：“原件和人，你开价，还是让我查？”

你没有可靠口供，门牌只证明这里曾接收过宗门的人。



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴点清灵石，亲手撤去案脚引灵符。秦蘅拿走写着自己名字的账页，跟你走出白线。你买下了原件，也把收钱的人留在了世上。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴把灵石推来，账册重新合拢。秦蘅没有喊她师姐，只把自己的名字念了一遍。你收了钱，从白线外离开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}

### hehuan / handed

秦蘅还活着，手腕上的引灵线一端扣在案脚。宋箴把账册横在她面前：“长老付过价。她留下，外堂才有药领。”

“我的名字在册上，不等于我答应过。”秦蘅扯住线头。晏绮罗看着宋箴：“原件和人，你开价，还是让我查？”

宋箴知道信使已被送走，合上账册：“你把能对账的人交出去了，现在打算拿什么指控我？”



#### 1. 买下原件，把秦蘅带离仪式

支付 48 灵石；取得账册原件并救出秦蘅，不战斗。宋箴收款后离开，未被杀死。

结果：宋箴点清灵石，亲手撤去案脚引灵符。秦蘅拿走写着自己名字的账页，跟你走出白线。你买下了原件，也把收钱的人留在了世上。

规则：{"key":"purchase","goldCost":48,"questItem":"hehuan_ledger_original","hehuanFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"boughtLedger":true,"agentSpared":true}}

#### 2. 没有可靠证词，仍逼他放人

证据不足，交涉将失败并立即与宋箴交战，玩家先手；获胜才救出秦蘅、取得原件，失败结束本局。

结果：宋箴把空白处转向你：“人已送走，证词也没有。你说我签过字，拿给谁看？”他按住案下兵刃。

规则：{"key":"negotiate_failed","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 3. 拔扇，连人带原件一起带走

立即与宋箴交战，玩家先手；胜利后取得原件、救出秦蘅并领取一份正常精英战利，失败结束本局。

结果：晏绮罗将扇骨挑开案上引灵线。宋箴起身拔刃，原件仍压在他的左手下。

规则：{"key":"attack","battle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","hehuanBattle":{"victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}},"hehuanBattle":{"enemyId":"raider","kind":"elite","name":"宗门代理·宋箴","victoryFlags":{"rescueReached":true,"rescuedQinHeng":true,"ledgerOriginal":true,"killedAgent":true,"agentDefeated":true},"victoryOutcome":"宋箴倒下，秦蘅自己从案后取出账册。她走出仪式白线：“我肯作证，也要自己决定以后去哪。”原件收入你的包裹。","victoryItems":["hehuan_ledger_original"]}}

#### 4. 收下封口钱，不带人回去

获得 55 灵石；不取得原件，不救秦蘅；她仍留在宋箴看守的仪式中。之后不能把此事写成营救。

结果：宋箴把灵石推来，账册重新合拢。秦蘅没有喊她师姐，只把自己的名字念了一遍。你收了钱，从白线外离开。

规则：{"key":"hush","goldGain":55,"hehuanFlags":{"rescueReached":true,"tookHushMoney":true,"rescueAbandoned":true,"agentSpared":true}}