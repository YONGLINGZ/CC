# 原件只够交给一方

- 事件 ID：`hehuan_ledger`
- 规则来源：dev/hehuan.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

接应者往晏绮罗身后看了一眼，看的是空处。他伸手要她的行囊，她将扇横了过来。

接应者将两张空纸叠在一起，推回晏绮罗面前。

## 选项

### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 晏绮罗将原册摊在灯下。抄录人一行行核验，留下副本、草药与护符，门外一直没有第二个人。

**规则字段：**

- **questItem**：hehuan_ledger_copy
- **hehuanItemsRemove**：
  - hehuan_ledger_original
- **guard**：14
- **itemGrants**：
  - 
    - **id**：herb
    - **count**：2
- **hehuanFlags**：
  - **ledgerOriginal**：false
  - **ledgerPublished**：true
  - **ledgerCopy**：true
  - **publicWitnessSupport**：true
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 接应者封好账册，付清灵石和药。晏绮罗数钱时，接应者已经在封纸上压了第二道印。

**规则字段：**

- **goldGain**：65
- **itemGrants**：
  - 
    - **id**：spirit_pill
    - **count**：2
- **hehuanItemsRemove**：
  - hehuan_ledger_original
- **hehuanFlags**：
  - **ledgerOriginal**：false
  - **returnedLedger**：true
  - **sectSupport**：true
  - **qinTrustLost**：false
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

**结果：** 晏绮罗只露出一行签名：“外堂的药钱，现在重算。”对方咬着牙放下钱和功诀，她将原件贴身藏好。

**规则字段：**

- **goldGain**：32
- **cardIds**：
  - H12
- **hehuanFlags**：
  - **ledgerLeverage**：true
  - **sectHostile**：true
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 晏绮罗将原件逐页送进火里。接应者等到最后一页烧黑，才重新坐下。

**规则字段：**

- **heal**：10
- **itemGrants**：
  - 
    - **id**：herb
    - **count**：2
- **hehuanItemsRemove**：
  - hehuan_ledger_original
- **hehuanFlags**：
  - **ledgerOriginal**：false
  - **ledgerDestroyed**：true
  - **qinOwnPath**：true
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

**结果：** 你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

**规则字段：**

- **hehuanFlags**：
  - **ledgerDispositionMissed**：true

## 机器可读字段摘录

- **id**：hehuan_ledger
- **name**：原件只够交给一方
- **type**：
- **glyph**：纱
- **kicker**：合欢旧案
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：新增角色事件。晏绮罗个人剧情，按实际营救、证词与账册处置显示分支；不覆盖原地图节点。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### hehuan / default

接应者往晏绮罗身后看了一眼，看的是空处。他伸手要她的行囊，她将扇横了过来。

接应者将两张空纸叠在一起，推回晏绮罗面前。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原册摊在灯下。抄录人一行行核验，留下副本、草药与护符，门外一直没有第二个人。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好账册，付清灵石和药。晏绮罗数钱时，接应者已经在封纸上压了第二道印。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗只露出一行签名：“外堂的药钱，现在重算。”对方咬着牙放下钱和功诀，她将原件贴身藏好。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件逐页送进火里。接应者等到最后一页烧黑，才重新坐下。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}

### hehuan / evidence

接应者往晏绮罗身后看了一眼，看的是空处。他伸手要她的行囊，她将扇横了过来。

路引抄件被风掀开，接应者看到自己的宗门印记，伸手按住。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原册摊在灯下。抄录人一行行核验，留下副本、草药与护符，门外一直没有第二个人。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好账册，付清灵石和药。晏绮罗数钱时，接应者已经在封纸上压了第二道印。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗只露出一行签名：“外堂的药钱，现在重算。”对方咬着牙放下钱和功诀，她将原件贴身藏好。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件逐页送进火里。接应者等到最后一页烧黑，才重新坐下。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}

### hehuan / rescued-original

秦蘅站在门外，将门留着一条缝：“我等你谈完。但别再给我签什么。”

接应者将两张空纸叠在一起，推回晏绮罗面前。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。

结果：晏绮罗摊开账册。秦蘅从门缝进来，自己取笔署名，写完又出去等。护送者替晏绮罗系上护符，草药搁在原册旁。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。

结果：接应者封好账册，付清灵石和药。晏绮罗追到门口，秦蘅已把等她的那条门缝带上了。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。

结果：晏绮罗只露出一行签名：“外堂的药钱，现在重算。”对方咬着牙放下钱和功诀，她将原件贴身藏好。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。

结果：晏绮罗将原件逐页送进火里。秦蘅先看纸烧完，拿起自己留的那页姓名，离开了门口。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

### hehuan / hush

接应者先看见钱袋，往晏绮罗身后看了一眼：“就你一个？”

接应者将两张空纸叠在一起，推回晏绮罗面前。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原册摊在灯下。抄录人一行行核验，留下副本、草药与护符，门外一直没有第二个人。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好账册，付清灵石和药。晏绮罗数钱时，接应者已经在封纸上压了第二道印。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗只露出一行签名：“外堂的药钱，现在重算。”对方咬着牙放下钱和功诀，她将原件贴身藏好。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件逐页送进火里。接应者等到最后一页烧黑，才重新坐下。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 保留封口钱，不伪称已带回证据

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：接应者不再问账，转而清点你收过的钱。秦蘅不在门外，晏绮罗没有替这个空位编一个圆满的说法。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}

### hehuan / handed

接应者往晏绮罗身后看了一眼，看的是空处。他伸手要她的行囊，她将扇横了过来。

接应者说季远不能来，说完把窗关上。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原册摊在灯下。抄录人一行行核验，留下副本、草药与护符，门外一直没有第二个人。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好账册，付清灵石和药。晏绮罗数钱时，接应者已经在封纸上压了第二道印。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗只露出一行签名：“外堂的药钱，现在重算。”对方咬着牙放下钱和功诀，她将原件贴身藏好。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件逐页送进火里。接应者等到最后一页烧黑，才重新坐下。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}