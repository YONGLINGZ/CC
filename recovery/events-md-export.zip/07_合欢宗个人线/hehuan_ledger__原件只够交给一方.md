# 原件只够交给一方

- 事件 ID：`hehuan_ledger`
- 规则来源：dev/hehuan.js；呈现改写：dev/event-editorial.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

接应者追到断亭，打开一只空匣：“长老说，原件交回来，外堂还有药钱。你若拿去给别人看，便别再用宗门的名号。”

接应者只见到你一个人，先看行囊，再问账册；秦蘅仍未被你带出仪式。

眼前没有当初信使的口供，空缺不能由一句传闻补上。

## 选项

### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 晏绮罗把原件摊在各宗见证人面前，签名的人只写亲见的部分。护送者将护符系在她腕上；秦蘅若愿出面，名字由她自己写。

**规则字段：**

- **questItem**：hehuan_ledger_copy
- **hehuanItemsRemove**：
  - hehuan_ledger_original
- **guard**：14
- **itemGrants**：
  - 
    - **id**：herb
    - **count**：2
- **hehuanFlags**：
  - **ledgerOriginal**：false
  - **ledgerPublished**：true
  - **ledgerCopy**：true
  - **publicWitnessSupport**：true
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 接应者封好原件，把灵石和药逐件放下。晏绮罗没有再留下可公开核对的那一册。秦蘅若已获救，便独自收起行囊，不再替她作证。

**规则字段：**

- **goldGain**：65
- **itemGrants**：
  - 
    - **id**：spirit_pill
    - **count**：2
- **hehuanItemsRemove**：
  - hehuan_ledger_original
- **hehuanFlags**：
  - **ledgerOriginal**：false
  - **returnedLedger**：true
  - **sectSupport**：true
  - **qinTrustLost**：false
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

**结果：** 晏绮罗将原件贴身收好，只让接应者看了一行签名。“外堂的药钱，从这里重新算。”对方付钱留下功诀；把柄仍在你手里，秦蘅的名字也仍在册中。

**规则字段：**

- **goldGain**：32
- **cardIds**：
  - H12
- **hehuanFlags**：
  - **ledgerLeverage**：true
  - **sectHostile**：true
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 秦蘅把自己的账页先投入火中，其余原件随后烧尽。“我不替长老守口。”她说，“但以后也别拿这本账替我决定。”晏绮罗留下药，让她自己择路。

**规则字段：**

- **heal**：10
- **itemGrants**：
  - 
    - **id**：herb
    - **count**：2
- **hehuanItemsRemove**：
  - hehuan_ledger_original
- **hehuanFlags**：
  - **ledgerOriginal**：false
  - **ledgerDestroyed**：true
  - **qinOwnPath**：true
- **requiresHehuanItem**：hehuan_ledger_original
- **locked**：true

### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

**结果：** 你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

**规则字段：**

- **hehuanFlags**：
  - **ledgerDispositionMissed**：true

## 机器可读字段摘录

- **id**：hehuan_ledger
- **name**：原件只够交给一方
- **type**：
- **glyph**：纱
- **kicker**：合欢旧案
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：新增角色事件。晏绮罗个人剧情，按实际营救、证词与账册处置显示分支；不覆盖原地图节点。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### hehuan / default

接应者追到断亭，打开一只空匣：“长老说，原件交回来，外堂还有药钱。你若拿去给别人看，便别再用宗门的名号。”

接应者只见到你一个人，先看行囊，再问账册；秦蘅仍未被你带出仪式。

眼前没有当初信使的口供，空缺不能由一句传闻补上。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗把原件摊在各宗见证人面前，签名的人只写亲见的部分。护送者将护符系在她腕上；秦蘅若愿出面，名字由她自己写。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好原件，把灵石和药逐件放下。晏绮罗没有再留下可公开核对的那一册。秦蘅若已获救，便独自收起行囊，不再替她作证。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件贴身收好，只让接应者看了一行签名。“外堂的药钱，从这里重新算。”对方付钱留下功诀；把柄仍在你手里，秦蘅的名字也仍在册中。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：秦蘅把自己的账页先投入火中，其余原件随后烧尽。“我不替长老守口。”她说，“但以后也别拿这本账替我决定。”晏绮罗留下药，让她自己择路。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}

### hehuan / evidence

接应者追到断亭，打开一只空匣：“长老说，原件交回来，外堂还有药钱。你若拿去给别人看，便别再用宗门的名号。”

接应者只见到你一个人，先看行囊，再问账册；秦蘅仍未被你带出仪式。

你仍能拿路引抄件逐字对照，但原件的去向只能按手中实物说明。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗把原件摊在各宗见证人面前，签名的人只写亲见的部分。护送者将护符系在她腕上；秦蘅若愿出面，名字由她自己写。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好原件，把灵石和药逐件放下。晏绮罗没有再留下可公开核对的那一册。秦蘅若已获救，便独自收起行囊，不再替她作证。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件贴身收好，只让接应者看了一行签名。“外堂的药钱，从这里重新算。”对方付钱留下功诀；把柄仍在你手里，秦蘅的名字也仍在册中。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：秦蘅把自己的账页先投入火中，其余原件随后烧尽。“我不替长老守口。”她说，“但以后也别拿这本账替我决定。”晏绮罗留下药，让她自己择路。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}

### hehuan / rescued-original

接应者追到断亭，打开一只空匣：“长老说，原件交回来，外堂还有药钱。你若拿去给别人看，便别再用宗门的名号。”

秦蘅站在门外：“救命的事我记着。可账上别再替我签一个新主人。”

眼前没有当初信使的口供，空缺不能由一句传闻补上。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。

结果：晏绮罗把原件摊在各宗见证人面前，签名的人只写亲见的部分。护送者将护符系在她腕上；秦蘅若愿出面，名字由她自己写。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。

结果：接应者封好原件，把灵石和药逐件放下。晏绮罗没有再留下可公开核对的那一册。秦蘅若已获救，便独自收起行囊，不再替她作证。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。

结果：晏绮罗将原件贴身收好，只让接应者看了一行签名。“外堂的药钱，从这里重新算。”对方付钱留下功诀；把柄仍在你手里，秦蘅的名字也仍在册中。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。

结果：秦蘅把自己的账页先投入火中，其余原件随后烧尽。“我不替长老守口。”她说，“但以后也别拿这本账替我决定。”晏绮罗留下药，让她自己择路。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":false}

### hehuan / hush

接应者追到断亭，打开一只空匣：“长老说，原件交回来，外堂还有药钱。你若拿去给别人看，便别再用宗门的名号。”

接应者看见你收过的封口款袋：“这趟安静得很。账册呢？”案后的秦蘅没有跟来。

眼前没有当初信使的口供，空缺不能由一句传闻补上。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗把原件摊在各宗见证人面前，签名的人只写亲见的部分。护送者将护符系在她腕上；秦蘅若愿出面，名字由她自己写。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好原件，把灵石和药逐件放下。晏绮罗没有再留下可公开核对的那一册。秦蘅若已获救，便独自收起行囊，不再替她作证。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件贴身收好，只让接应者看了一行签名。“外堂的药钱，从这里重新算。”对方付钱留下功诀；把柄仍在你手里，秦蘅的名字也仍在册中。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：秦蘅把自己的账页先投入火中，其余原件随后烧尽。“我不替长老守口。”她说，“但以后也别拿这本账替我决定。”晏绮罗留下药，让她自己择路。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 保留封口钱，不伪称已带回证据

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：接应者不再问账，转而清点你收过的钱。秦蘅不在门外，晏绮罗没有替这个空位编一个圆满的说法。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}

### hehuan / handed

接应者追到断亭，打开一只空匣：“长老说，原件交回来，外堂还有药钱。你若拿去给别人看，便别再用宗门的名号。”

接应者只见到你一个人，先看行囊，再问账册；秦蘅仍未被你带出仪式。

季远已被交给巡使；接应者说他不能来。你没有假称他已同意替你作证。



#### 1. 公布原件，请证人各自署名

交出原件供核验，留下副本；下场战斗首回合获得 14 护盾，获得回春草×2。不能同时收宗门的回购钱。 未持有账册原件，不能按此方式处置。

结果：晏绮罗把原件摊在各宗见证人面前，签名的人只写亲见的部分。护送者将护符系在她腕上；秦蘅若愿出面，名字由她自己写。

规则：{"key":"publish","questItem":"hehuan_ledger_copy","hehuanItemsRemove":["hehuan_ledger_original"],"guard":14,"itemGrants":[{"id":"herb","count":2}],"hehuanFlags":{"ledgerOriginal":false,"ledgerPublished":true,"ledgerCopy":true,"publicWitnessSupport":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 2. 把原件交回宗门，换取补给

交出原件，获得 65 灵石与聚灵丹×2；失去原件，不能再用它公布或索价。 未持有账册原件，不能按此方式处置。

结果：接应者封好原件，把灵石和药逐件放下。晏绮罗没有再留下可公开核对的那一册。秦蘅若已获救，便独自收起行囊，不再替她作证。

规则：{"key":"return","goldGain":65,"itemGrants":[{"id":"spirit_pill","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"returnedLedger":true,"sectSupport":true,"qinTrustLost":false},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 3. 保留原件，向长老索价

保留原件，获得 32 灵石与「满堂红」；不获公开证人的护符或宗门回购补给。 未持有账册原件，不能按此方式处置。

结果：晏绮罗将原件贴身收好，只让接应者看了一行签名。“外堂的药钱，从这里重新算。”对方付钱留下功诀；把柄仍在你手里，秦蘅的名字也仍在册中。

规则：{"key":"leverage","goldGain":32,"cardIds":["H12"],"hehuanFlags":{"ledgerLeverage":true,"sectHostile":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 4. 只带秦蘅离开，当面毁掉原件

须已救出秦蘅；焚毁原件，恢复 10 生命并获得回春草×2，不取得封口或回购钱。 未持有账册原件，不能按此方式处置。

结果：秦蘅把自己的账页先投入火中，其余原件随后烧尽。“我不替长老守口。”她说，“但以后也别拿这本账替我决定。”晏绮罗留下药，让她自己择路。

规则：{"key":"destroy","heal":10,"itemGrants":[{"id":"herb","count":2}],"hehuanItemsRemove":["hehuan_ledger_original"],"hehuanFlags":{"ledgerOriginal":false,"ledgerDestroyed":true,"qinOwnPath":true},"requiresHehuanItem":"hehuan_ledger_original","locked":true}

#### 5. 没有原件，不接新的处置约定

不改变资源，不补发原件、不自动救人。此前交人、收款或错过证词的事实仍保留。

结果：你摊开手里实际有的纸页，没有账册原件。接应者收回空匣，你继续赶路；失踪者和旧账都还未结清。

规则：{"key":"unfinished","hehuanFlags":{"ledgerDispositionMissed":true}}