# 门前的路引

- 事件 ID：`hehuan_checkpoint`
- 规则来源：dev/hehuan.js；呈现改写：dev/event-editorial.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

巡使岳衡拦住一名合欢宗信使，地上散着三张路引：“昨夜失踪三个人，有人看见你把他们带进山门。”

信使季远指着签押：“路引是我送的，人是宋箴领走的。你不问他，拿我顶罪？”晏绮罗蹲下拾纸：“签了字的人，得把话说清楚。”

## 选项

### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

**点击前已知代价：** 支付18灵石

**结果：** 你点清担保金，岳衡在路引旁记下晏绮罗的名字。季远走到灯下：“我会留在接收处等你，不替长老改口供。”

**规则字段：**

- **goldCost**：18
- **hehuanFlags**：
  - **metMessenger**：true
  - **messengerAvailable**：true
  - **guaranteedMessenger**：true
  - **guaranteePaid**：18
  - **checkpointResolved**：true

### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

**结果：** 你把接收地点与宋箴的签押抄在同一页。岳衡答应暂缓送人离山，仍扣着季远；你带走的是证据，不是一份已经完成的营救。

**规则字段：**

- **questItem**：hehuan_route_copy
- **hehuanFlags**：
  - **metMessenger**：true
  - **checkpointEvidence**：true
  - **messengerDetained**：true
  - **checkpointResolved**：true

### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

**结果：** 岳衡接过缚绳，付清协查补贴。季远没有再求你：“到接收处自己看吧。”他被带走，你没有取得他的口供。

**规则字段：**

- **goldGain**：14
- **hehuanFlags**：
  - **metMessenger**：true
  - **handedMessenger**：true
  - **messengerAvailable**：false
  - **checkpointResolved**：true

### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

**点击前已知代价：** 进入巡使·岳衡战，落败结束本局

**结果：** 晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

**规则字段：**

- **battle**：
  - **enemyId**：orthodox_patrol
  - **kind**：fight
  - **name**：巡使·岳衡
  - **hehuanBattle**：
    - **victoryFlags**：
      - **metMessenger**：true
      - **messengerAvailable**：true
      - **killedPatrol**：true
      - **checkpointResolved**：true
    - **victoryOutcome**：岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。
    - **victoryItems**：

- **hehuanBattle**：
  - **enemyId**：orthodox_patrol
  - **kind**：fight
  - **name**：巡使·岳衡
  - **victoryFlags**：
    - **metMessenger**：true
    - **messengerAvailable**：true
    - **killedPatrol**：true
    - **checkpointResolved**：true
  - **victoryOutcome**：岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。
  - **victoryItems**：


### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

**结果：** 晏绮罗收起扇子，没有替任何一方签字。巡使带走信使；你只记得接收地点的大致方向，调查少了这一份口供。

**规则字段：**

- **hehuanFlags**：
  - **missedMessenger**：true
  - **checkpointResolved**：true

## 机器可读字段摘录

- **id**：hehuan_checkpoint
- **name**：门前的路引
- **type**：
- **glyph**：纱
- **kicker**：合欢旧案
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：新增角色事件。晏绮罗个人剧情，按实际营救、证词与账册处置显示分支；不覆盖原地图节点。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### hehuan / default

巡使岳衡拦住一名合欢宗信使，地上散着三张路引：“昨夜失踪三个人，有人看见你把他们带进山门。”

信使季远指着签押：“路引是我送的，人是宋箴领走的。你不问他，拿我顶罪？”晏绮罗蹲下拾纸：“签了字的人，得把话说清楚。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：你点清担保金，岳衡在路引旁记下晏绮罗的名字。季远走到灯下：“我会留在接收处等你，不替长老改口供。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：你把接收地点与宋箴的签押抄在同一页。岳衡答应暂缓送人离山，仍扣着季远；你带走的是证据，不是一份已经完成的营救。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡接过缚绳，付清协查补贴。季远没有再求你：“到接收处自己看吧。”他被带走，你没有取得他的口供。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收起扇子，没有替任何一方签字。巡使带走信使；你只记得接收地点的大致方向，调查少了这一份口供。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / evidence

巡使岳衡拦住一名合欢宗信使，地上散着三张路引：“昨夜失踪三个人，有人看见你把他们带进山门。”

信使季远指着签押：“路引是我送的，人是宋箴领走的。你不问他，拿我顶罪？”晏绮罗蹲下拾纸：“签了字的人，得把话说清楚。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：你点清担保金，岳衡在路引旁记下晏绮罗的名字。季远走到灯下：“我会留在接收处等你，不替长老改口供。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：你把接收地点与宋箴的签押抄在同一页。岳衡答应暂缓送人离山，仍扣着季远；你带走的是证据，不是一份已经完成的营救。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡接过缚绳，付清协查补贴。季远没有再求你：“到接收处自己看吧。”他被带走，你没有取得他的口供。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收起扇子，没有替任何一方签字。巡使带走信使；你只记得接收地点的大致方向，调查少了这一份口供。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / rescued-original

巡使岳衡拦住一名合欢宗信使，地上散着三张路引：“昨夜失踪三个人，有人看见你把他们带进山门。”

信使季远指着签押：“路引是我送的，人是宋箴领走的。你不问他，拿我顶罪？”晏绮罗蹲下拾纸：“签了字的人，得把话说清楚。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：你点清担保金，岳衡在路引旁记下晏绮罗的名字。季远走到灯下：“我会留在接收处等你，不替长老改口供。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：你把接收地点与宋箴的签押抄在同一页。岳衡答应暂缓送人离山，仍扣着季远；你带走的是证据，不是一份已经完成的营救。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡接过缚绳，付清协查补贴。季远没有再求你：“到接收处自己看吧。”他被带走，你没有取得他的口供。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收起扇子，没有替任何一方签字。巡使带走信使；你只记得接收地点的大致方向，调查少了这一份口供。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / hush

巡使岳衡拦住一名合欢宗信使，地上散着三张路引：“昨夜失踪三个人，有人看见你把他们带进山门。”

信使季远指着签押：“路引是我送的，人是宋箴领走的。你不问他，拿我顶罪？”晏绮罗蹲下拾纸：“签了字的人，得把话说清楚。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：你点清担保金，岳衡在路引旁记下晏绮罗的名字。季远走到灯下：“我会留在接收处等你，不替长老改口供。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：你把接收地点与宋箴的签押抄在同一页。岳衡答应暂缓送人离山，仍扣着季远；你带走的是证据，不是一份已经完成的营救。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡接过缚绳，付清协查补贴。季远没有再求你：“到接收处自己看吧。”他被带走，你没有取得他的口供。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收起扇子，没有替任何一方签字。巡使带走信使；你只记得接收地点的大致方向，调查少了这一份口供。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / handed

巡使岳衡拦住一名合欢宗信使，地上散着三张路引：“昨夜失踪三个人，有人看见你把他们带进山门。”

信使季远指着签押：“路引是我送的，人是宋箴领走的。你不问他，拿我顶罪？”晏绮罗蹲下拾纸：“签了字的人，得把话说清楚。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：你点清担保金，岳衡在路引旁记下晏绮罗的名字。季远走到灯下：“我会留在接收处等你，不替长老改口供。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：你把接收地点与宋箴的签押抄在同一页。岳衡答应暂缓送人离山，仍扣着季远；你带走的是证据，不是一份已经完成的营救。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡接过缚绳，付清协查补贴。季远没有再求你：“到接收处自己看吧。”他被带走，你没有取得他的口供。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收起扇子，没有替任何一方签字。巡使带走信使；你只记得接收地点的大致方向，调查少了这一份口供。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}