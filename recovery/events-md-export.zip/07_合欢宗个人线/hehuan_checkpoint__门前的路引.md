# 门前的路引

- 事件 ID：`hehuan_checkpoint`
- 规则来源：dev/hehuan.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

岳衡用剑鞘压着季远的肩，路引上的红印被雨洇开。季远想说话，被他往下按了一下。

晏绮罗展开扇：“路引给我看。”岳衡不动，她笑了一下：“好，我看人。你再按，他就把要问的话吐地上了。”

## 选项

### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

**点击前已知代价：** 支付18灵石

**结果：** 晏绮罗数出担保金。岳衡在路引上写她的名字，季远揉着肩：“她们说是送药。到了才知道送的是人。”

**规则字段：**

- **goldCost**：18
- **hehuanFlags**：
  - **metMessenger**：true
  - **messengerAvailable**：true
  - **guaranteedMessenger**：true
  - **guaranteePaid**：18
  - **checkpointResolved**：true

### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

**结果：** 晏绮罗将宋箴的签押照着抄下。季远被带走时回头看她一眼，她没有合扇，一直站到转角看不见。

**规则字段：**

- **questItem**：hehuan_route_copy
- **hehuanFlags**：
  - **metMessenger**：true
  - **checkpointEvidence**：true
  - **messengerDetained**：true
  - **checkpointResolved**：true

### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

**结果：** 岳衡收紧缚绳，付出补贴。季远没有再求，只说了一遍接收处的门色。晏绮罗收钱的手慢了一下。

**规则字段：**

- **goldGain**：14
- **hehuanFlags**：
  - **metMessenger**：true
  - **handedMessenger**：true
  - **messengerAvailable**：false
  - **checkpointResolved**：true

### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

**点击前已知代价：** 进入巡使·岳衡战，落败结束本局

**结果：** 晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

**规则字段：**

- **battle**：
  - **enemyId**：orthodox_patrol
  - **kind**：fight
  - **name**：巡使·岳衡
  - **hehuanBattle**：
    - **victoryFlags**：
      - **metMessenger**：true
      - **messengerAvailable**：true
      - **killedPatrol**：true
      - **checkpointResolved**：true
    - **victoryOutcome**：岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。
    - **victoryItems**：

- **hehuanBattle**：
  - **enemyId**：orthodox_patrol
  - **kind**：fight
  - **name**：巡使·岳衡
  - **victoryFlags**：
    - **metMessenger**：true
    - **messengerAvailable**：true
    - **killedPatrol**：true
    - **checkpointResolved**：true
  - **victoryOutcome**：岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。
  - **victoryItems**：


### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

**结果：** 晏绮罗收扇，从剑鞘旁走过去。季远想追着说门色，岳衡将他拽回身边。

**规则字段：**

- **hehuanFlags**：
  - **missedMessenger**：true
  - **checkpointResolved**：true

## 机器可读字段摘录

- **id**：hehuan_checkpoint
- **name**：门前的路引
- **type**：
- **glyph**：纱
- **kicker**：合欢旧案
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：新增角色事件。晏绮罗个人剧情，按实际营救、证词与账册处置显示分支；不覆盖原地图节点。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### hehuan / default

岳衡用剑鞘压着季远的肩，路引上的红印被雨洇开。季远想说话，被他往下按了一下。

晏绮罗展开扇：“路引给我看。”岳衡不动，她笑了一下：“好，我看人。你再按，他就把要问的话吐地上了。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：晏绮罗数出担保金。岳衡在路引上写她的名字，季远揉着肩：“她们说是送药。到了才知道送的是人。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：晏绮罗将宋箴的签押照着抄下。季远被带走时回头看她一眼，她没有合扇，一直站到转角看不见。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡收紧缚绳，付出补贴。季远没有再求，只说了一遍接收处的门色。晏绮罗收钱的手慢了一下。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收扇，从剑鞘旁走过去。季远想追着说门色，岳衡将他拽回身边。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / evidence

岳衡用剑鞘压着季远的肩，路引上的红印被雨洇开。季远想说话，被他往下按了一下。

晏绮罗展开扇：“路引给我看。”岳衡不动，她笑了一下：“好，我看人。你再按，他就把要问的话吐地上了。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：晏绮罗数出担保金。岳衡在路引上写她的名字，季远揉着肩：“她们说是送药。到了才知道送的是人。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：晏绮罗将宋箴的签押照着抄下。季远被带走时回头看她一眼，她没有合扇，一直站到转角看不见。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡收紧缚绳，付出补贴。季远没有再求，只说了一遍接收处的门色。晏绮罗收钱的手慢了一下。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收扇，从剑鞘旁走过去。季远想追着说门色，岳衡将他拽回身边。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / rescued-original

岳衡用剑鞘压着季远的肩，路引上的红印被雨洇开。季远想说话，被他往下按了一下。

晏绮罗展开扇：“路引给我看。”岳衡不动，她笑了一下：“好，我看人。你再按，他就把要问的话吐地上了。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：晏绮罗数出担保金。岳衡在路引上写她的名字，季远揉着肩：“她们说是送药。到了才知道送的是人。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：晏绮罗将宋箴的签押照着抄下。季远被带走时回头看她一眼，她没有合扇，一直站到转角看不见。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡收紧缚绳，付出补贴。季远没有再求，只说了一遍接收处的门色。晏绮罗收钱的手慢了一下。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收扇，从剑鞘旁走过去。季远想追着说门色，岳衡将他拽回身边。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / hush

岳衡用剑鞘压着季远的肩，路引上的红印被雨洇开。季远想说话，被他往下按了一下。

晏绮罗展开扇：“路引给我看。”岳衡不动，她笑了一下：“好，我看人。你再按，他就把要问的话吐地上了。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：晏绮罗数出担保金。岳衡在路引上写她的名字，季远揉着肩：“她们说是送药。到了才知道送的是人。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：晏绮罗将宋箴的签押照着抄下。季远被带走时回头看她一眼，她没有合扇，一直站到转角看不见。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡收紧缚绳，付出补贴。季远没有再求，只说了一遍接收处的门色。晏绮罗收钱的手慢了一下。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收扇，从剑鞘旁走过去。季远想追着说门色，岳衡将他拽回身边。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}

### hehuan / handed

岳衡用剑鞘压着季远的肩，路引上的红印被雨洇开。季远想说话，被他往下按了一下。

晏绮罗展开扇：“路引给我看。”岳衡不动，她笑了一下：“好，我看人。你再按，他就把要问的话吐地上了。”



#### 1. 替信使交钱担保

支付 18 灵石；信使暂时获释，你成为担保人。他会在后段留下证词，担保不是永久免罪。

结果：晏绮罗数出担保金。岳衡在路引上写她的名字，季远揉着肩：“她们说是送药。到了才知道送的是人。”

规则：{"key":"guarantee","goldCost":18,"hehuanFlags":{"metMessenger":true,"messengerAvailable":true,"guaranteedMessenger":true,"guaranteePaid":18,"checkpointResolved":true}}

#### 2. 先查路引，让双方说清楚

当面对照签押，取得路引抄件；不交担保金。信使暂留巡使处，尚未获释；本次不战斗。

结果：晏绮罗将宋箴的签押照着抄下。季远被带走时回头看她一眼，她没有合扇，一直站到转角看不见。

规则：{"key":"investigate","questItem":"hehuan_route_copy","hehuanFlags":{"metMessenger":true,"checkpointEvidence":true,"messengerDetained":true,"checkpointResolved":true}}

#### 3. 把信使交给巡使

获得 14 灵石协查补贴；失去本次向信使取证的机会。交人的事实不会被之后改变立场抹去。

结果：岳衡收紧缚绳，付出补贴。季远没有再求，只说了一遍接收处的门色。晏绮罗收钱的手慢了一下。

规则：{"key":"handover","goldGain":14,"hehuanFlags":{"metMessenger":true,"handedMessenger":true,"messengerAvailable":false,"checkpointResolved":true}}

#### 4. 我不信你这套，动手放人

立即与巡使岳衡交战，玩家先手；获胜才放走信使并留下杀巡使的记录，失败结束本局。没有先发放的证词或和平奖励。

结果：晏绮罗将纱横在缚绳前。岳衡拔剑：“这一剑，你是要替谁作保？”

规则：{"key":"attack","battle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","hehuanBattle":{"victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}},"hehuanBattle":{"enemyId":"orthodox_patrol","kind":"fight","name":"巡使·岳衡","victoryFlags":{"metMessenger":true,"messengerAvailable":true,"killedPatrol":true,"checkpointResolved":true},"victoryOutcome":"岳衡倒下，季远解开缚绳。他愿为接收地点作证，却不肯将你的杀人说成只是交涉。","victoryItems":[]}}

#### 5. 这事与我无关，离开

不支付、不战斗、不取得路引或证词；仍可沿原路线寻找接收处。

结果：晏绮罗收扇，从剑鞘旁走过去。季远想追着说门色，岳衡将他拽回身边。

规则：{"key":"leave","hehuanFlags":{"missedMessenger":true,"checkpointResolved":true}}