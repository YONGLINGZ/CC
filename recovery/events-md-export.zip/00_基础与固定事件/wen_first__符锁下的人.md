# 符锁下的人

- 事件 ID：`wen_first`
- 导出来源：当前规则数据

## 背景与叙事

玄烬符锁把一个削瘦的人钉在山门残柱上。她说自己叫闻人烛，曾为实验记数，直到记录里出现了同门的名字。

“我知道她们如何封路。”她抬起染黑的手，“锁上的阵纹，我画过。只求你替我松开这一道。”

## 选项

### 1. 断开符锁 · 失去 5 生命，获得 20 灵石

当前生命须大于5。

**结果：** 铁锁落地，一缕黑印从锁口缠到你腕上。闻人烛拿布替你擦过：“擦不净，得另找洗符砂。”

**规则字段：**

- **hpCost**：5
- **goldGain**：20
- **flags**：
  - **wenFreed**：true
- **relationship**：
  - **status**：解锁相助
  - **text**：你释放了闻人烛，锁中的黑印留在腕上。
- **tone**：warning
- **disabled**：false

### 2. 付 15 灵石买一页记录，不解锁

获得阵眼记录，下一战首回合护盾 +6。

**结果：** 她把记录卷成细条递给你，指明一处可避开的阵眼。你记下了手法，却没有伸手碰锁。

**规则字段：**

- **goldCost**：15
- **guard**：6
- **flags**：
  - **wenFreed**：false
  - **wenEvidence**：true
- **relationship**：
  - **status**：只谈交易
  - **text**：你买走了一页记录，没有替她断锁。
- **disabled**：false

### 3. 留下水，继续寻找出路

没有数值变化。

**结果：** 她喝得很慢，没有再许诺什么。你走开时，听见她重新开始数锁上那些符文。

**规则字段：**

- **flags**：
  - **wenFreed**：false
- **relationship**：
  - **status**：未施援手
  - **text**：你留下水，没有替她断锁。
- **disabled**：false

## 机器可读字段摘录

- **id**：wen_first
- **name**：符锁下的人
- **type**：
- **glyph**：烛
- **kicker**：故人行迹
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 显式状态审阅快照

### assassin / default

玄烬符锁把一个削瘦的人钉在山门残柱上。她说自己叫闻人烛，曾为实验记数，直到记录里出现了同门的名字。

“我知道她们如何封路。”她抬起染黑的手，“锁上的阵纹，我画过。只求你替我松开这一道。”



#### 1. 断开符锁 · 失去 5 生命，获得 20 灵石

当前生命须大于5。

结果：铁锁落地，一缕黑印从锁口缠到你腕上。闻人烛拿布替你擦过：“擦不净，得另找洗符砂。”

规则：{"hpCost":5,"goldGain":20,"flags":{"wenFreed":true},"relationship":{"status":"解锁相助","text":"你释放了闻人烛，锁中的黑印留在腕上。"},"tone":"warning","disabled":false}

#### 2. 付 15 灵石买一页记录，不解锁

获得阵眼记录，下一战首回合护盾 +6。

结果：她把记录卷成细条递给你，指明一处可避开的阵眼。你记下了手法，却没有伸手碰锁。

规则：{"goldCost":15,"guard":6,"flags":{"wenFreed":false,"wenEvidence":true},"relationship":{"status":"只谈交易","text":"你买走了一页记录，没有替她断锁。"},"disabled":false}

#### 3. 留下水，继续寻找出路

没有数值变化。

结果：她喝得很慢，没有再许诺什么。你走开时，听见她重新开始数锁上那些符文。

规则：{"flags":{"wenFreed":false},"relationship":{"status":"未施援手","text":"你留下水，没有替她断锁。"},"disabled":false}

### sword / default

玄烬符锁把一个削瘦的人钉在山门残柱上。她说自己叫闻人烛，曾为实验记数，直到记录里出现了同门的名字。

“我知道她们如何封路。”她抬起染黑的手，“锁上的阵纹，我画过。只求你替我松开这一道。”



#### 1. 断开符锁 · 失去 5 生命，获得 20 灵石

当前生命须大于5。

结果：铁锁落地，一缕黑印从锁口缠到你腕上。闻人烛拿布替你擦过：“擦不净，得另找洗符砂。”

规则：{"hpCost":5,"goldGain":20,"flags":{"wenFreed":true},"relationship":{"status":"解锁相助","text":"你释放了闻人烛，锁中的黑印留在腕上。"},"tone":"warning","disabled":false}

#### 2. 付 15 灵石买一页记录，不解锁

获得阵眼记录，下一战首回合护盾 +6。

结果：她把记录卷成细条递给你，指明一处可避开的阵眼。你记下了手法，却没有伸手碰锁。

规则：{"goldCost":15,"guard":6,"flags":{"wenFreed":false,"wenEvidence":true},"relationship":{"status":"只谈交易","text":"你买走了一页记录，没有替她断锁。"},"disabled":false}

#### 3. 留下水，继续寻找出路

没有数值变化。

结果：她喝得很慢，没有再许诺什么。你走开时，听见她重新开始数锁上那些符文。

规则：{"flags":{"wenFreed":false},"relationship":{"status":"未施援手","text":"你留下水，没有替她断锁。"},"disabled":false}

### sovereign / default

玄烬符锁把一个削瘦的人钉在山门残柱上。她说自己叫闻人烛，曾为实验记数，直到记录里出现了同门的名字。

“我知道她们如何封路。”她抬起染黑的手，“锁上的阵纹，我画过。只求你替我松开这一道。”



#### 1. 断开符锁 · 失去 5 生命，获得 20 灵石

当前生命须大于5。

结果：铁锁落地，一缕黑印从锁口缠到你腕上。闻人烛拿布替你擦过：“擦不净，得另找洗符砂。”

规则：{"hpCost":5,"goldGain":20,"flags":{"wenFreed":true},"relationship":{"status":"解锁相助","text":"你释放了闻人烛，锁中的黑印留在腕上。"},"tone":"warning","disabled":false}

#### 2. 付 15 灵石买一页记录，不解锁

获得阵眼记录，下一战首回合护盾 +6。

结果：她把记录卷成细条递给你，指明一处可避开的阵眼。你记下了手法，却没有伸手碰锁。

规则：{"goldCost":15,"guard":6,"flags":{"wenFreed":false,"wenEvidence":true},"relationship":{"status":"只谈交易","text":"你买走了一页记录，没有替她断锁。"},"disabled":false}

#### 3. 留下水，继续寻找出路

没有数值变化。

结果：她喝得很慢，没有再许诺什么。你走开时，听见她重新开始数锁上那些符文。

规则：{"flags":{"wenFreed":false},"relationship":{"status":"未施援手","text":"你留下水，没有替她断锁。"},"disabled":false}