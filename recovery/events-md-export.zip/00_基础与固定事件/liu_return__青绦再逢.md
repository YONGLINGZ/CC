# 青绦再逢

- 事件 ID：`liu_return`
- 导出来源：当前规则数据

## 背景与叙事

你在断桥药棚再次遇见柳照青。她的师姐裹着厚被，靠着商盟借来的药活了下来。

她认出你，神色并不怨怼：“药材是借来的，我还要还账。你若要药，和旁人同价。”

## 前置／后续回应

雾锁山门：你曾指路，却没有留下救人。

## 选项

### 1. 买一包伤药 · 支付 15 灵石，恢复 18 生命

治疗不超过最大生命。

**结果：** 她没有多收一文，也没有少给一味药。药棚外的雾还在，至少这碗药是热的。

**规则字段：**

- **goldCost**：15
- **heal**：18
- **flags**：
  - **liuReturned**：true
- **relationship**：
  - **status**：相识
  - **text**：你向她买了药，彼此都记住了名字。
- **disabled**：false

### 2. 替药棚守夜 · 失去 4 生命，获得 25 灵石

当前生命须大于 4。

**结果：** 你挡住了夜里摸来的影子，袖口被瘴刃划开。天亮前，柳照青把药棚凑出的盘缠塞给你。

**规则字段：**

- **hpCost**：4
- **goldGain**：25
- **flags**：
  - **liuReturned**：true
  - **liuAid**：true
- **relationship**：
  - **status**：互相照应
  - **text**：你替药棚守了一夜，收下凑来的盘缠。
- **tone**：good
- **disabled**：false

### 3. 只报平安，继续深入

不支付代价，也不领取药物。

**结果：** 柳照青替你拨正衣领，只说：“到了井边，先听风，不要先看水。”

**规则字段：**

- **flags**：
  - **liuReturned**：false
- **relationship**：
  - **status**：一面之缘
  - **text**：你报了平安，没有在药棚停留。
- **disabled**：false

## 机器可读字段摘录

- **id**：liu_return
- **name**：青绦再逢
- **type**：
- **glyph**：药
- **kicker**：故人行迹
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 显式状态审阅快照

### assassin / default

你在断桥药棚再次遇见柳照青。她的师姐裹着厚被，靠着商盟借来的药活了下来。

她认出你，神色并不怨怼：“药材是借来的，我还要还账。你若要药，和旁人同价。”

雾锁山门：你曾指路，却没有留下救人。

#### 1. 买一包伤药 · 支付 15 灵石，恢复 18 生命

治疗不超过最大生命。

结果：她没有多收一文，也没有少给一味药。药棚外的雾还在，至少这碗药是热的。

规则：{"goldCost":15,"heal":18,"flags":{"liuReturned":true},"relationship":{"status":"相识","text":"你向她买了药，彼此都记住了名字。"},"disabled":false}

#### 2. 替药棚守夜 · 失去 4 生命，获得 25 灵石

当前生命须大于 4。

结果：你挡住了夜里摸来的影子，袖口被瘴刃划开。天亮前，柳照青把药棚凑出的盘缠塞给你。

规则：{"hpCost":4,"goldGain":25,"flags":{"liuReturned":true,"liuAid":true},"relationship":{"status":"互相照应","text":"你替药棚守了一夜，收下凑来的盘缠。"},"tone":"good","disabled":false}

#### 3. 只报平安，继续深入

不支付代价，也不领取药物。

结果：柳照青替你拨正衣领，只说：“到了井边，先听风，不要先看水。”

规则：{"flags":{"liuReturned":false},"relationship":{"status":"一面之缘","text":"你报了平安，没有在药棚停留。"},"disabled":false}

### sword / default

你在断桥药棚再次遇见柳照青。她的师姐裹着厚被，靠着商盟借来的药活了下来。

她认出你，神色并不怨怼：“药材是借来的，我还要还账。你若要药，和旁人同价。”

雾锁山门：你曾指路，却没有留下救人。

#### 1. 买一包伤药 · 支付 15 灵石，恢复 18 生命

治疗不超过最大生命。

结果：她没有多收一文，也没有少给一味药。药棚外的雾还在，至少这碗药是热的。

规则：{"goldCost":15,"heal":18,"flags":{"liuReturned":true},"relationship":{"status":"相识","text":"你向她买了药，彼此都记住了名字。"},"disabled":false}

#### 2. 替药棚守夜 · 失去 4 生命，获得 25 灵石

当前生命须大于 4。

结果：你挡住了夜里摸来的影子，袖口被瘴刃划开。天亮前，柳照青把药棚凑出的盘缠塞给你。

规则：{"hpCost":4,"goldGain":25,"flags":{"liuReturned":true,"liuAid":true},"relationship":{"status":"互相照应","text":"你替药棚守了一夜，收下凑来的盘缠。"},"tone":"good","disabled":false}

#### 3. 只报平安，继续深入

不支付代价，也不领取药物。

结果：柳照青替你拨正衣领，只说：“到了井边，先听风，不要先看水。”

规则：{"flags":{"liuReturned":false},"relationship":{"status":"一面之缘","text":"你报了平安，没有在药棚停留。"},"disabled":false}

### sovereign / default

你在断桥药棚再次遇见柳照青。她的师姐裹着厚被，靠着商盟借来的药活了下来。

她认出你，神色并不怨怼：“药材是借来的，我还要还账。你若要药，和旁人同价。”

雾锁山门：你曾指路，却没有留下救人。

#### 1. 买一包伤药 · 支付 15 灵石，恢复 18 生命

治疗不超过最大生命。

结果：她没有多收一文，也没有少给一味药。药棚外的雾还在，至少这碗药是热的。

规则：{"goldCost":15,"heal":18,"flags":{"liuReturned":true},"relationship":{"status":"相识","text":"你向她买了药，彼此都记住了名字。"},"disabled":false}

#### 2. 替药棚守夜 · 失去 4 生命，获得 25 灵石

当前生命须大于 4。

结果：你挡住了夜里摸来的影子，袖口被瘴刃划开。天亮前，柳照青把药棚凑出的盘缠塞给你。

规则：{"hpCost":4,"goldGain":25,"flags":{"liuReturned":true,"liuAid":true},"relationship":{"status":"互相照应","text":"你替药棚守了一夜，收下凑来的盘缠。"},"tone":"good","disabled":false}

#### 3. 只报平安，继续深入

不支付代价，也不领取药物。

结果：柳照青替你拨正衣领，只说：“到了井边，先听风，不要先看水。”

规则：{"flags":{"liuReturned":false},"relationship":{"status":"一面之缘","text":"你报了平安，没有在药棚停留。"},"disabled":false}