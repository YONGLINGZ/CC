# 该留下什么记录

- 事件 ID：`tinglan_record`
- 规则来源：dev/mechanist.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生拿机尺顶开袖口：“我一直等院里再派人来。你怎么来得这么晚？”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”

## 选项

### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

**规则字段：**

- **questItem**：tl_public_record
- **guard**：12
- **itemGrants**：
  - 
    - **id**：herb
    - **count**：2
- **flags**：
  - **tlFinalDisposition**：public
  - **tlRescuerOut**：true
  - **tlWitnessPublic**：true
- **locked**：true

### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

**规则字段：**

- **guard**：8
- **itemGrants**：
  - 
    - **id**：spirit_pill
    - **count**：2
- **flags**：
  - **tlFinalDisposition**：internal
  - **tlRescuerOut**：true
  - **tlInternalReceipt**：true

### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

**结果：** 灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

**规则字段：**

- **goldGain**：70
- **cardIds**：
  - J37
- **flags**：
  - **tlFinalDisposition**：silence
  - **tlRescuerOut**：true
  - **tlWitnessTrustLost**：true

### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

**结果：** 她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

**规则字段：**

- **questItem**：tl_delivery_list
- **cardIds**：
  - J11
- **flags**：
  - **tlFinalDisposition**：kept
  - **tlRescuerOut**：true

## 机器可读字段摘录

- **id**：tinglan_record
- **name**：该留下什么记录
- **type**：
- **glyph**：机
- **kicker**：同心线轴
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：已改写。改写现场、直接请求与已知代价；保留原数值及历史前提。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### mechanist / default

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生拿机尺顶开袖口：“我一直等院里再派人来。你怎么来得这么晚？”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / bridge-repaired

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生把阿川的画认了出来：“对，就是桥口那家。上头让我们先清那里。”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":false}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / bridge-investigated

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生对上原芯上的刻痕：“清桥那行是我刻的。下面还有一句，没刻进去。”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":false}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / bridge-scrapped

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生摸到缺齿的保险销，立即把手缩开：“磨这个的时候，我在场。”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / original-returned

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生对上原芯上的刻痕：“清桥那行是我刻的。下面还有一句，没刻进去。”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / copy-kept

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生对上原芯上的刻痕：“清桥那行是我刻的。下面还有一句，没刻进去。”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":false}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / public

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生拿机尺顶开袖口：“我一直等院里再派人来。你怎么来得这么晚？”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / internal

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生拿机尺顶开袖口：“我一直等院里再派人来。你怎么来得这么晚？”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / silence

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生拿机尺顶开袖口：“我一直等院里再派人来。你怎么来得这么晚？”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}

### mechanist / kept

失联救援队的邱生还活着，左腿被木骨支架撑着。他从袖尺暗匣里抽出一页出货账：改销、清桥、转交玄烬教，末尾有院内批准的日期。

邱生拿机尺顶开袖口：“我一直等院里再派人来。你怎么来得这么晚？”

吴桐从后门进来，没看邱生，先把七十枚灵石排在桌上：“这张纸给我。伤员我接出去，院里的名字我来背。”邱生按住暗匣：“你来背，还是等我也不在了？”



#### 1. 带出原账，署名公开

须保留桥口证词或控制原芯；获得署名的公开记录、下战12护盾与回春草2份；此后不收院内封口钱。

结果：陆听澜把出货账夹进桥口的记录里，在第一页写下自己的名字。邱生问能不能也写，她把笔递过去。吴桐起身要走，跨过门槛时说：“以后的修件，别再来找我。”

规则：{"key":"publish","questItem":"tl_public_record","guard":12,"itemGrants":[{"id":"herb","count":2}],"flags":{"tlFinalDisposition":"public","tlRescuerOut":true,"tlWitnessPublic":true},"locked":true}

#### 2. 交原账追责，要求留下签押

交出这页出货账，获得下战8护盾、聚灵丹2枚；已有旧证据保留。院内援助继续，雾外会有后续回信。

结果：陆听澜把七十枚灵石推开，只让吴桐在收件处签字。“先封改销工坊，把邱生送出去。少一项，我就带这张收条去院门口。”吴桐签完，看了看邱生的腿，叫人搬来担架。

规则：{"key":"internal","guard":8,"itemGrants":[{"id":"spirit_pill","count":2}],"flags":{"tlFinalDisposition":"internal","tlRescuerOut":true,"tlInternalReceipt":true}}

#### 3. 收下灵石，把这页账留给吴桐

获得70灵石与「雷羽齐发」；不取得公开记录或院内护符。邱生会知道你接受了这笔交易。

结果：灵石进袋时，邱生把袖尺的暗匣合上了。陆听澜伸手扶他，他撑着桌子自己站起来：“不用了。你修你的东西。”吴桐将出货账贴身收好，又留下了一张雷羽图。

规则：{"key":"silence","goldGain":70,"cardIds":["J37"],"flags":{"tlFinalDisposition":"silence","tlRescuerOut":true,"tlWitnessTrustLost":true}}

#### 4. 带邱生离开，暂时留下原账

取得出货账与「急修」一张；不自动公布或宣告追责完成。

结果：她先背起邱生，叫承山顶开门，才把账页塞进机匣。鸣镝停到屋檐下，她低声骂了一句：“说了别往屋顶上扎。”邱生在背后笑了一声，笑到一半变成了咳嗽。

规则：{"key":"keep","questItem":"tl_delivery_list","cardIds":["J11"],"flags":{"tlFinalDisposition":"kept","tlRescuerOut":true}}