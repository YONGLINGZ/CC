# 桥口的旧机

- 事件 ID：`tinglan_bridge`
- 规则来源：dev/mechanist.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。

## 选项

### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

**点击前已知代价：** 支付20灵石

**结果：** 她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

**规则字段：**

- **goldCost**：20
- **questItem**：tl_testimony
- **cardIds**：
  - J09
- **flags**：
  - **tlBridgeMode**：repaired
  - **tlHasTestimony**：true
  - **tlBridgeResolved**：true

### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

**点击前已知代价：** 支付20灵石

**结果：** 她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

**规则字段：**

- **goldCost**：20
- **questItem**：tl_testimony
- **cardIds**：
  - J11
- **flags**：
  - **tlBridgeMode**：repaired
  - **tlHasTestimony**：true
  - **tlBridgeResolved**：true

### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

**结果：** 斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

**规则字段：**

- **goldGain**：20
- **questItem**：tl_broken_pin
- **flags**：
  - **tlBridgeMode**：scrapped
  - **tlBridgeResolved**：true

### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

**点击前已知代价：** 进入山魈战，落败结束本局

**结果：** 原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

**规则字段：**

- **questItem**：tl_control_record
- **battle**：
  - **enemyId**：ape
  - **name**：山魈
  - **kind**：fight
- **flags**：
  - **tlBridgeMode**：investigated
  - **tlHasControl**：true
  - **tlBridgeResolved**：true

### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

**结果：** 陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

**规则字段：**

- **flags**：
  - **tlBridgeMode**：left
  - **tlBridgeResolved**：true

## 机器可读字段摘录

- **id**：tinglan_bridge
- **name**：桥口的旧机
- **type**：
- **glyph**：机
- **kicker**：同心线轴
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：已改写。改写现场、直接请求与已知代价；保留原数值及历史前提。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### mechanist / default

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / bridge-repaired

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / bridge-investigated

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / bridge-scrapped

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / original-returned

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / copy-kept

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / public

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / internal

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / silence

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}

### mechanist / kept

旧机半身陷在桥墩里，脚边压着一只红鞋。阿川抱着光脚的儿子挡住去路：“你们造的东西，刚才差点把他压死！”

陆听澜蹲下，剪断供芯线。保险销缺了半齿，磨口朝里。“这是后来改的。”她把销钉举到灯下，阿川却只看那只鞋：“修好以后，还会踩下来吗？”

桥洞里传来山魈刨石的响声。陆听澜把红鞋勾出来，鞋底还沾着温热的泥。



#### 1. 买替换件修桥，记下「展匣」

支付20灵石；取得桥口证词，获得「展匣」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_deploy","goldCost":20,"questItem":"tl_testimony","cardIds":["J09"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 2. 买替换件修桥，记下「急修」

支付20灵石；取得桥口证词，获得「急修」一张。不恢复战斗机体耐久。

结果：她把新销敲入桥架，叫阿川带孩子先过。男人走到对岸才折回来，用烧黑的木片画出旧机行走的路线。“它绕开了三家棚子，偏偏踩我们这一家。”

规则：{"key":"repair_repair","goldCost":20,"questItem":"tl_testimony","cardIds":["J11"],"flags":{"tlBridgeMode":"repaired","tlHasTestimony":true,"tlBridgeResolved":true}}

#### 3. 拆掉旧机，带走保险销

获得20灵石与损坏保险销；不取得完整控制记录，也没有修好桥。

结果：斧子落下前，陆听澜先取出那颗销。木骨断开，桥下的响动停了一瞬。阿川领孩子踩着浅水过去，没接她递来的鞋，鞋被放在了桥桩上。

规则：{"key":"scrap","goldGain":20,"questItem":"tl_broken_pin","flags":{"tlBridgeMode":"scrapped","tlBridgeResolved":true}}

#### 4. 留下拆读原芯

取得护桥机控制记录；离开时与山魈进行一场普通战。胜利后才继续，落败结束本局。

结果：原芯吐出两行刻痕：半夜三更，有人拆过保险销；天亮前，旧机收到一条“清桥”指令。陆听澜收起原芯，桥洞里的山魈已经爬上来了。

规则：{"key":"investigate","questItem":"tl_control_record","battle":{"enemyId":"ape","name":"山魈","kind":"fight"},"flags":{"tlBridgeMode":"investigated","tlHasControl":true,"tlBridgeResolved":true}}

#### 5. 绕过旧机，继续找救援队

不花钱，不取得证词或原芯；不会阻断七境主线。

结果：陆听澜将供芯线压在石下，又在桥桩上划了一道禁启线。阿川牵着孩子走进浅水，鞋还留在原处。

规则：{"key":"leave","flags":{"tlBridgeMode":"left","tlBridgeResolved":true}}