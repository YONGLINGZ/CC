# 院里的封存令

- 事件 ID：`tinglan_seal`
- 规则来源：dev/mechanist.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”

## 选项

### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

**结果：** 吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

**规则字段：**

- **goldGain**：35
- **nextDriveAid**：2
- **mechanistItemsRemove**：
  - tl_control_record
- **flags**：
  - **tlEvidenceReturned**：true
  - **tlHasControl**：false
  - **tlSealMode**：original
- **locked**：true

### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

**结果：** 她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

**规则字段：**

- **questItem**：tl_record_copy
- **nextDriveAid**：2
- **flags**：
  - **tlKeptCopy**：true
  - **tlSealMode**：copy
- **locked**：true

### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

**结果：** 吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

**规则字段：**

- **cardIds**：
  - J36
- **flags**：
  - **tlSealMode**：statement
  - **tlNamedEmptyLine**：true
- **locked**：true

### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

**结果：** 她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

**规则字段：**

- **flags**：
  - **tlSealMode**：refused

## 机器可读字段摘录

- **id**：tinglan_seal
- **name**：院里的封存令
- **type**：
- **glyph**：机
- **kicker**：同心线轴
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：已改写。改写现场、直接请求与已知代价；保留原数值及历史前提。

### 改造前正文



### 改造前选项与结果



## 显式状态审阅快照

### mechanist / default

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / bridge-repaired

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

阿川画的纸被压在茶碗下。管事看了一遍路线，又把纸翻过来，看见陆听澜写的尺寸。

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":false}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / bridge-investigated

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

陆听澜将原芯立在桌角。管事认出芯槽的编号，先伸手盖住验真印。

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":false}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":false}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / bridge-scrapped

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

保险销滚到茶碗边。管事用袖口包着捡起，没有碰那道磨痕。

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":false}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / original-returned

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / copy-kept

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

陆听澜将原芯立在桌角。管事认出芯槽的编号，先伸手盖住验真印。

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":false}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":false}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / public

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / internal

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / silence

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}

### mechanist / kept

接应棚里，管事吴桐把炉火拨旺：“先把东西交我。院里查清了，自然给你答复。茶别喝，放了一夜。”

管事掀开机匣，只看见陆听澜自己的工具。他把封存纸压平：“找到东西再来。”

“保险销照我们的图纸改的。”陆听澜说。吴桐把门闩推上：“你现在拿出去，所有人只会记得天工院机关杀人。先替那些还等着修桥的人想想。”



#### 1. 交回原芯，索取封存回执

须持有护桥机控制记录；交出原芯，获得35灵石，下场开战额外2驱动一次。

结果：吴桐给原芯贴了两层封纸。陆听澜按住他的笔：“写清收的是几号芯。别只写旧器。”他停了一会儿，补上编号，把灵芯与回执一起推过来。

规则：{"key":"return","goldGain":35,"nextDriveAid":2,"mechanistItemsRemove":["tl_control_record"],"flags":{"tlEvidenceReturned":true,"tlHasControl":false,"tlSealMode":"original"},"locked":true}

#### 2. 交刻痕拓纸，保留原芯

须持有护桥机控制记录；取得刻痕拓纸，下场开战额外2驱动一次。原芯仍保留；没有35灵石。

结果：她用炭纸拓完芯槽，把拓纸推过去。吴桐伸手要原芯，她先合上了机匣。“够你查出货的人了。”他没接这句话，只将一枚备用灵芯放到桌边。

规则：{"key":"copy","questItem":"tl_record_copy","nextDriveAid":2,"flags":{"tlKeptCopy":true,"tlSealMode":"copy"},"locked":true}

#### 3. 交出桥口证词的抄件，请他当场查账

须持有桥口证词或保险销；保留现有实物，获得「翼骨校准」；不取得灵芯援助。

结果：吴桐翻到出货栏，停在一个空行。陆听澜用机尺压住那一页。“你再往前翻。”管事抽回手，拿出一份旧校准图：“路上用得着。出货的事，我查。”

规则：{"key":"statement","cardIds":["J36"],"flags":{"tlSealMode":"statement","tlNamedEmptyLine":true},"locked":true}

#### 4. 不交，自己去找出货的人

不取得灵石或灵芯援助。持有的实物全部保留。

结果：她把机匣背好。吴桐追到门边，递来一张空白封存纸；她没接。纸在炉边烤得翘起一角，管事伸手压住，烫得缩了一下。

规则：{"key":"refuse","flags":{"tlSealMode":"refused"}}