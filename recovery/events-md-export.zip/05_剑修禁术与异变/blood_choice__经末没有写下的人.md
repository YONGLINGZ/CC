# 经末没有写下的人

- 事件 ID：`blood_choice`
- 规则来源：dev/expansion.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

## 选项

### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

**点击前已知代价：** 反复使用禁术可能改变心性；清心玉可护心神，不治毒、不逆转已有异变

**结果：** 沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

**规则字段：**

- **cardIds**：
  - D12
- **learnDemonic**：true
- **flags**：
  - **bloodEnding**：power
- **disabled**：false

### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

**点击前已知代价：** 反复使用禁术可能改变心性；清心玉可护心神，不治毒、不逆转已有异变

**结果：** 沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

**规则字段：**

- **cardIds**：
  - D08
  - D09
- **learnDemonic**：true
- **flags**：
  - **bloodEnding**：limit
- **disabled**：false

### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

**结果：** 沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

**规则字段：**

- **cardIds**：
  - S16
- **heal**：10
- **flags**：
  - **bloodEnding**：seal
- **disabled**：false

### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

**规则字段：**

- **itemGrants**：
  - 
    - **id**：fullheal_pill
    - **count**：1
- **flags**：
  - **bloodEnding**：medicine
- **disabled**：false

## 机器可读字段摘录

- **id**：blood_choice
- **name**：经末没有写下的人
- **type**：
- **glyph**：血
- **kicker**：经页与代价
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：保留并精修说明。保留本局血术选择回执及封卷不逆转异变。

### 改造前正文

经卷最后一页写着“万命皆可为我”。下方有人补了一行小字，又被重重涂掉。

送信的人带来药棚的回执：仍有人活着，也仍有人死去，没有一种选择能抹掉所有损失。你终于读清被涂掉的字：“那我还算谁？”

### 改造前选项与结果

**收下血海终篇**

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：你合上经卷。它没有替你决定下一个人的命，只让那个决定更容易被做出。

**留一式夺生，不取血海**

获得「夺生指」「血衣」，不获得血海终篇。

结果：你给自己留下一条边界。边界不会自动守住，要靠以后的每一次出手。

**封存终篇，磨成自己的剑诀**

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：你没有宣称从此无错，只把尚未做出的选择留在自己手里。已经走过的路，也不会被封书抹去。

**不再留卷，带走救命的药**

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：药放进包裹，书留在匣中。你没有为这一刻写一个永远有效的结论。

## 显式状态审阅快照

### sword / default

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”



#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-sacrifice-fallen-false

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁选择以身为价。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-sacrifice-fallen-true

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁选择以身为价。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-drain-fallen-false

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁研读过夺生经页。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-drain-fallen-true

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁研读过夺生经页。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-refuse-fallen-false

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁坚持自己的剑道。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-refuse-fallen-true

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁坚持自己的剑道。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-leave-fallen-false

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁没有留下经页。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}

### sword / method-leave-fallen-true

经卷最后写着“万命皆可为我”。下面一行被反复涂黑，纸已经擦破。

沈霜白将纸迎着火光，读出洞边剩下的几个字：“那我还算谁？”

你在药阁没有留下经页。

#### 1. 收下血海终篇

获得「血海归墟」。先付生命再伤敌吸血；死亡不会靠后续吸血挽回。

结果：沈霜白将终篇贴身收好。火光熄下去，她伸手去护经页，指腹留下一个新的血印。

规则：{"cardIds":["D12"],"learnDemonic":true,"flags":{"bloodEnding":"power"},"disabled":false}

#### 2. 留一式夺生，不取血海

获得「夺生指」「血衣」，不获得血海终篇。

结果：沈霜白撕下两式，剩下的压回匣底。她关了两次，才把翘起的纸角关进去。

规则：{"cardIds":["D08","D09"],"learnDemonic":true,"flags":{"bloodEnding":"limit"},"disabled":false}

#### 3. 封存终篇，磨成自己的剑诀

获得 「万川归寂」；恢复 10 生命，不逆转已经发生的异变。

结果：沈霜白把终篇封进匣中，换手重新握剑。旧诀从第一式走到最后，剑尖终于不再颤。

规则：{"cardIds":["S16"],"heal":10,"flags":{"bloodEnding":"seal"},"disabled":false}

#### 4. 不再留卷，带走救命的药

获得九转还元丹 1 份；不获得禁术，不逆转异变。

结果：沈霜白取走药瓶，用原来的红绳扎紧匣盖。走到门口，瓶内丹丸碰响了一次。

规则：{"itemGrants":[{"id":"fullheal_pill","count":1}],"flags":{"bloodEnding":"medicine"},"disabled":false}