# 血盏中不肯散的光

- 事件 ID：`blood_lesson`
- 导出来源：当前规则数据

## 背景与叙事

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

## 选项

### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

**结果：** 你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

**规则字段：**

- **cardIds**：
  - D07
  - D09
- **learnDemonic**：true
- **flags**：
  - **bloodMethod**：sacrifice
- **disabled**：false

### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

**结果：** 指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

**规则字段：**

- **cardIds**：
  - D08
- **learnDemonic**：true
- **flags**：
  - **bloodMethod**：drain
- **disabled**：false

### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

**结果：** 你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

**规则字段：**

- **cardIds**：
  - S12
- **heal**：6
- **flags**：
  - **bloodMethod**：refuse
- **disabled**：false

### 4. 不留下经页

获得回春草 1 份，不学习禁术。

**结果：** 草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

**规则字段：**

- **itemGrants**：
  - 
    - **id**：herb
    - **count**：1
- **flags**：
  - **bloodMethod**：leave
- **disabled**：false

## 机器可读字段摘录

- **id**：blood_lesson
- **name**：血盏中不肯散的光
- **type**：
- **glyph**：血
- **kicker**：经页与代价
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 显式状态审阅快照

### sword / default

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。



#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-sacrifice-fallen-false

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁选择以身为价。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-sacrifice-fallen-true

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁选择以身为价。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-drain-fallen-false

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁研读过夺生经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-drain-fallen-true

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁研读过夺生经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-refuse-fallen-false

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁坚持自己的剑道。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-refuse-fallen-true

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁坚持自己的剑道。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-leave-fallen-false

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁没有留下经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-leave-fallen-true

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

你在药阁没有留下经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}