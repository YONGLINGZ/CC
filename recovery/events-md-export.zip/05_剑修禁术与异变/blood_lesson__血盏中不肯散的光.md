# 血盏中不肯散的光

- 事件 ID：`blood_lesson`
- 规则来源：dev/expansion.js；呈现改写：dev/event-editorial.js、dev/story-v5.js、dev/story-factions-v5.js、dev/story-bosses-v5.js
- 角色／历史前提：自然调度保持源模块条件；每个显式输入见本文件快照和同名 snapshots.json。
- 导出来源：当前规则数据

## 背景与叙事

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

## 选项

### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

**点击前已知代价：** 反复使用禁术可能改变心性；清心玉可护心神，不治毒、不逆转已有异变

**结果：** 沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

**规则字段：**

- **cardIds**：
  - D07
  - D09
- **learnDemonic**：true
- **flags**：
  - **bloodMethod**：sacrifice
- **disabled**：false

### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

**点击前已知代价：** 反复使用禁术可能改变心性；清心玉可护心神，不治毒、不逆转已有异变

**结果：** 经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

**规则字段：**

- **cardIds**：
  - D08
- **learnDemonic**：true
- **flags**：
  - **bloodMethod**：drain
- **disabled**：false

### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

**结果：** 沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

**规则字段：**

- **cardIds**：
  - S12
- **heal**：6
- **flags**：
  - **bloodMethod**：refuse
- **disabled**：false

### 4. 不留下经页

获得回春草 1 份，不学习禁术。

**点击前已知代价：** 所得药物收入包裹，须服用才生效

**结果：** 沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

**规则字段：**

- **itemGrants**：
  - 
    - **id**：herb
    - **count**：1
- **flags**：
  - **bloodMethod**：leave
- **disabled**：false

## 机器可读字段摘录

- **id**：blood_lesson
- **name**：血盏中不肯散的光
- **type**：
- **glyph**：血
- **kicker**：经页与代价
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 本轮改造核对

状态：保留并精修说明。保留旧修直接诱惑及自损／吸血／正诀分流，补充已知施术风险。

### 改造前正文

药阁的旧修将一缕血气压进剑锋：“命不能白取，自己的也一样。”她曾用禁术救回师妹，后来却开始把所有求医者当成试招的材料。

她愿意留下两种相反的手法：付出自己的生命换取爆发，或强行取走对手的生机。你也可以把经页封回匣中。

### 改造前选项与结果

**以身为价，学焚血之术**

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：你记下先付代价再落剑的次序，没有把损失写到别人的账上。但这并不能使禁术没有危险。

**研读夺生经页**

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：指尖的热意来得太容易。药阁旧修看着你的神情，想起自己第一次不再嫌这术太快的时候。

**坚持剑道，抄下护心正诀**

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：你抄下如何护住经脉，而非如何向经脉索取。她没有再劝，只将血盏盖好。

**不留下经页**

获得回春草 1 份，不学习禁术。

结果：草药有用，劝诱仍留在药阁。你没有替那位从未见过的师妹判断这份救命之恩。

## 显式状态审阅快照

### sword / default

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”



#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-sacrifice-fallen-false

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁选择以身为价。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-sacrifice-fallen-true

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁选择以身为价。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-drain-fallen-false

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁研读过夺生经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-drain-fallen-true

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁研读过夺生经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-refuse-fallen-false

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁坚持自己的剑道。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-refuse-fallen-true

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁坚持自己的剑道。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-leave-fallen-false

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁没有留下经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}

### sword / method-leave-fallen-true

旧修用血气稳住剑锋，一根指头却怎么也伸不直。

“我师妹活了。”她把血盏往前推，“后来见我就躲。你还听不听？”

你在药阁没有留下经页。

#### 1. 以身为价，学焚血之术

获得「焚血斩」「血衣」。使用禁术会扰动心神；清心玉可护灵台。

结果：沈霜白照着经页压住自己的血气，指节一寸寸发白。旧修看完起势，转身去洗那只一直洗不净的盏。

规则：{"cardIds":["D07","D09"],"learnDemonic":true,"flags":{"bloodMethod":"sacrifice"},"disabled":false}

#### 2. 研读夺生经页

获得「夺生指」。按实际生命伤害治疗；使用禁术会扰动心神。

结果：经页贴上掌心便热起来。旧修突然把另一只手藏到背后，没让沈霜白看清她指尖在抖。

规则：{"cardIds":["D08"],"learnDemonic":true,"flags":{"bloodMethod":"drain"},"disabled":false}

#### 3. 坚持剑道，抄下护心正诀

获得「霜天壁」，并恢复 6 生命；不学习禁术。

结果：沈霜白抄完护心诀，合上经页。旧修把血盏盖好，仍盯着盖沿渗出的一点红。

规则：{"cardIds":["S12"],"heal":6,"flags":{"bloodMethod":"refuse"},"disabled":false}

#### 4. 不留下经页

获得回春草 1 份，不学习禁术。

结果：沈霜白拿了药草。旧修将她没碰的经页叠好，压在那只缺了口的盏下。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"bloodMethod":"leave"},"disabled":false}