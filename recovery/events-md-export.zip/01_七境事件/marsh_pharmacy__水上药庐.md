# 水上药庐

- 事件 ID：`marsh_pharmacy`
- 导出来源：当前规则数据

## 背景与叙事

一间药庐用粗绳系在老柳上，案边的年轻人正把浸水的药纸重新晾干。

她没有问你来自哪里，只把两只药包推到干燥的一侧：“这一包养伤，那一包拔毒。看清了再拿。”

## 选项

### 1. 付 18 灵石，收一包凝露叶

获得凝露叶 ×2，收入包裹；每份恢复 12 生命。

**结果：** 你把灵石压在药纸下。她在两包凝露叶上各系了一根防潮细绳。

**规则字段：**

- **goldCost**：18
- **itemGrants**：
  - 
    - **id**：dewherb
    - **count**：2
- **disabled**：false

### 2. 付 35 灵石，取拔毒丹

获得百草解厄丹 ×1，收入包裹；服用时彻底解除毒素。

**结果：** 瓶口封蜡仍有余温。她确认你看清药名，才松开搭在瓶上的手。

**规则字段：**

- **goldCost**：35
- **itemGrants**：
  - 
    - **id**：antidote
    - **count**：1
- **disabled**：false

### 3. 帮她把药架搬上高处

获得回春草 ×1，不花费灵石。

**结果：** 药架稳稳落在梁上。临走时，一小束回春草被塞进了你的包裹。

**规则字段：**

- **itemGrants**：
  - 
    - **id**：herb
    - **count**：1
- **flags**：
  - **sevenPharmacyHelp**：true
- **disabled**：false

## 机器可读字段摘录

- **id**：marsh_pharmacy
- **name**：水上药庐
- **type**：
- **glyph**：药
- **kicker**：雾后见闻
- **tale**：
- **bossQuest**：
- **factionEvent**：


## 显式状态审阅快照

### assassin / default

一间药庐用粗绳系在老柳上，案边的年轻人正把浸水的药纸重新晾干。

她没有问你来自哪里，只把两只药包推到干燥的一侧：“这一包养伤，那一包拔毒。看清了再拿。”



#### 1. 付 18 灵石，收一包凝露叶

获得凝露叶 ×2，收入包裹；每份恢复 12 生命。

结果：你把灵石压在药纸下。她在两包凝露叶上各系了一根防潮细绳。

规则：{"goldCost":18,"itemGrants":[{"id":"dewherb","count":2}],"disabled":false}

#### 2. 付 35 灵石，取拔毒丹

获得百草解厄丹 ×1，收入包裹；服用时彻底解除毒素。

结果：瓶口封蜡仍有余温。她确认你看清药名，才松开搭在瓶上的手。

规则：{"goldCost":35,"itemGrants":[{"id":"antidote","count":1}],"disabled":false}

#### 3. 帮她把药架搬上高处

获得回春草 ×1，不花费灵石。

结果：药架稳稳落在梁上。临走时，一小束回春草被塞进了你的包裹。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"sevenPharmacyHelp":true},"disabled":false}

### sword / default

一间药庐用粗绳系在老柳上，案边的年轻人正把浸水的药纸重新晾干。

她没有问你来自哪里，只把两只药包推到干燥的一侧：“这一包养伤，那一包拔毒。看清了再拿。”



#### 1. 付 18 灵石，收一包凝露叶

获得凝露叶 ×2，收入包裹；每份恢复 12 生命。

结果：你把灵石压在药纸下。她在两包凝露叶上各系了一根防潮细绳。

规则：{"goldCost":18,"itemGrants":[{"id":"dewherb","count":2}],"disabled":false}

#### 2. 付 35 灵石，取拔毒丹

获得百草解厄丹 ×1，收入包裹；服用时彻底解除毒素。

结果：瓶口封蜡仍有余温。她确认你看清药名，才松开搭在瓶上的手。

规则：{"goldCost":35,"itemGrants":[{"id":"antidote","count":1}],"disabled":false}

#### 3. 帮她把药架搬上高处

获得回春草 ×1，不花费灵石。

结果：药架稳稳落在梁上。临走时，一小束回春草被塞进了你的包裹。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"sevenPharmacyHelp":true},"disabled":false}

### sovereign / default

一间药庐用粗绳系在老柳上，案边的年轻人正把浸水的药纸重新晾干。

她没有问你来自哪里，只把两只药包推到干燥的一侧：“这一包养伤，那一包拔毒。看清了再拿。”



#### 1. 付 18 灵石，收一包凝露叶

获得凝露叶 ×2，收入包裹；每份恢复 12 生命。

结果：你把灵石压在药纸下。她在两包凝露叶上各系了一根防潮细绳。

规则：{"goldCost":18,"itemGrants":[{"id":"dewherb","count":2}],"disabled":false}

#### 2. 付 35 灵石，取拔毒丹

获得百草解厄丹 ×1，收入包裹；服用时彻底解除毒素。

结果：瓶口封蜡仍有余温。她确认你看清药名，才松开搭在瓶上的手。

规则：{"goldCost":35,"itemGrants":[{"id":"antidote","count":1}],"disabled":false}

#### 3. 帮她把药架搬上高处

获得回春草 ×1，不花费灵石。

结果：药架稳稳落在梁上。临走时，一小束回春草被塞进了你的包裹。

规则：{"itemGrants":[{"id":"herb","count":1}],"flags":{"sevenPharmacyHelp":true},"disabled":false}